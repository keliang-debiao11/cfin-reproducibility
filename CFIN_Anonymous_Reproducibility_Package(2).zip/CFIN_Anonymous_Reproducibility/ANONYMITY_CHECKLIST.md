# Anonymous Repository Checklist

- No author names, affiliations, email addresses, acknowledgements, grant numbers, or personal usernames appear in tracked files.
- Repository URLs and local paths do not contain identifying names.
- Git history should be squashed or created in a fresh anonymous repository before submission.
- Remove operating-system metadata, notebook outputs, access tokens, dataset credentials, and absolute paths.
- Do not include raw datasets unless their licenses explicitly permit redistribution.
- Run `python scripts/validate_package.py` before every anonymous-repository release.
- Archive the accepted version in a DOI-assigning repository after the anonymous review stage.

