import pytest


torch = pytest.importorskip("torch")

from cfin_repro.models import CFIN, WeightedFocalLoss


def test_cfin_binary_shape_and_loss():
    model = CFIN(
        numerical_names=["math", "english"],
        categorical_names=["gender", "caste"],
        categorical_cardinalities=[3, 5],
        groups={"academic": ["math", "english"], "demographic": ["gender", "caste"]},
        output_dim=1,
        token_dim=32,
        group_encoder_layers=1,
        group_encoder_heads=4,
        group_ff_dim=64,
        context_encoder_layers=2,
        context_encoder_heads=4,
        context_ff_dim=128,
    )
    numerical = torch.randn(8, 2)
    categorical = torch.stack([torch.randint(0, 3, (8,)), torch.randint(0, 5, (8,))], dim=1)
    logits = model(numerical, categorical)
    assert logits.shape == (8, 1)
    loss = WeightedFocalLoss(torch.tensor([0.6, 4.0]), gamma=2.0)(
        logits, torch.randint(0, 2, (8,))
    )
    assert loss.ndim == 0
    assert torch.isfinite(loss)

