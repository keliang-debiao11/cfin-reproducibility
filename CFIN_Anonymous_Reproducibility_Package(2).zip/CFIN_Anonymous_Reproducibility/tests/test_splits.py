import pandas as pd

from cfin_repro.data import fixed_split_indices


def _counts(series, indices):
    return series.iloc[indices].value_counts().to_dict()


def test_inels_fixed_split_counts():
    target = pd.Series(["Retained"] * 18200 + ["Dropout"] * 900)
    train, test = fixed_split_indices(target, seed=2025, test_size=0.20)
    assert len(train) == 15280
    assert len(test) == 3820
    assert _counts(target, train) == {"Retained": 14560, "Dropout": 720}
    assert _counts(target, test) == {"Retained": 3640, "Dropout": 180}


def test_uci_fixed_split_counts():
    target = pd.Series(["Graduate"] * 2209 + ["Dropout"] * 1421 + ["Enrolled"] * 794)
    train, test = fixed_split_indices(target, seed=2025, test_size=0.20)
    assert len(train) == 3539
    assert len(test) == 885
    assert _counts(target, train) == {"Graduate": 1767, "Dropout": 1137, "Enrolled": 635}
    assert _counts(target, test) == {"Graduate": 442, "Dropout": 284, "Enrolled": 159}

