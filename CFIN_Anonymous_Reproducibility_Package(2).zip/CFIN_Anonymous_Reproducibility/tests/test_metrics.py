import numpy as np

from cfin_repro.metrics import evaluate_classification, mean_sd


def test_binary_metrics():
    y = np.array([0, 0, 1, 1])
    probabilities = np.array([0.1, 0.4, 0.6, 0.9])
    metrics = evaluate_classification(y, probabilities, threshold=0.5)
    assert metrics["accuracy"] == 1.0
    assert metrics["macro_f1"] == 1.0
    assert metrics["macro_auc"] == 1.0


def test_sample_sd():
    mean, sd = mean_sd([1.0, 2.0, 3.0])
    assert mean == 2.0
    assert sd == 1.0

