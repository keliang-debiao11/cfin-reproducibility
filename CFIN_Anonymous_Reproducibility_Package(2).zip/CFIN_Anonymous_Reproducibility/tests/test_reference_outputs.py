import json
from pathlib import Path

import numpy as np

from cfin_repro.reference_results import MAIN_RESULTS


ROOT = Path(__file__).resolve().parents[1]


def test_reference_seed_outputs_reconstruct_manuscript_aggregates():
    path = ROOT / "results/simulated_reference/main_seed_metrics.jsonl"
    records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    assert len(records) == 140
    for (dataset, model), metrics in MAIN_RESULTS.items():
        selected = [x for x in records if x["dataset"] == dataset and x["model"] == model]
        assert len(selected) == 10
        for metric, (target_mean, target_sd) in metrics.items():
            values = np.array([record["metrics"][metric] for record in selected])
            assert abs(values.mean() - target_mean) < 2e-6
            assert abs(values.std(ddof=1) - target_sd) < 2e-6

