import numpy as np

from cfin_repro.statistics import holm_adjust


def test_holm_adjustment_matches_inels_table_order():
    adjusted = holm_adjust([0.0031, 0.0004, 0.0006])
    np.testing.assert_allclose(adjusted, [0.0031, 0.0012, 0.0012])

