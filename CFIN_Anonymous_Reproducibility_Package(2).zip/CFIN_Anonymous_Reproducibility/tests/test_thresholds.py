import numpy as np

from cfin_repro.thresholds import select_macro_f1_threshold, threshold_grid


def test_threshold_grid_is_inclusive():
    grid = threshold_grid()
    assert len(grid) == 91
    assert grid[0] == 0.05
    assert grid[-1] == 0.95


def test_tie_break_prefers_closest_to_half():
    y = np.array([0, 0, 1, 1])
    probabilities = np.full(4, 0.5)
    threshold, _ = select_macro_f1_threshold(y, probabilities)
    assert threshold == 0.5

