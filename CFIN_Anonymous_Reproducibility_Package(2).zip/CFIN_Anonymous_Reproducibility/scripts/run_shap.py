#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.adapters import fit_predict
from cfin_repro.config import resolved_experiment_config
from cfin_repro.data import fixed_split_indices, load_dataset
from cfin_repro.experiment import _default_parameters, encode_target
from cfin_repro.training import predict_neural


def stratified_sample(indices: np.ndarray, labels: np.ndarray, size: int, seed: int) -> np.ndarray:
    if size >= len(indices):
        return indices
    selected, _ = train_test_split(
        indices,
        train_size=size,
        random_state=seed,
        stratify=labels[indices],
    )
    return np.sort(selected)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["inels", "uci", "all"], default="all")
    parser.add_argument("--config", default="configs/experiments/main.yaml")
    parser.add_argument("--seed", type=int, default=11)
    args = parser.parse_args()
    import shap
    import torch

    config = resolved_experiment_config(args.config)
    datasets = ["inels", "uci"] if args.dataset == "all" else [args.dataset]
    for name in datasets:
        dataset = load_dataset(name)
        target, _ = encode_target(name, dataset.target)
        train_indices, test_indices = fixed_split_indices(dataset.target, seed=2025, test_size=0.20)
        parameters = _default_parameters("cfin", config)
        fitted = fit_predict(
            "cfin", parameters, dataset, train_indices, test_indices, target, seed=args.seed
        )
        model = fitted.fitted_model
        preprocessor = fitted.preprocessor
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        background_indices = stratified_sample(train_indices, target, 256, 2025)
        explained_size = 1000 if name == "inels" else len(test_indices)
        explained_indices = stratified_sample(test_indices, target, explained_size, 2025)
        feature_names = list(dataset.frame.columns)

        def predict(frame_values):
            frame = pd.DataFrame(frame_values, columns=feature_names)
            arrays = preprocessor.transform_neural(frame)
            probabilities = predict_neural(
                model,
                (arrays.numerical, arrays.categorical),
                batch_size=256,
                device=device,
            )
            return probabilities if name == "inels" else probabilities[:, 0]

        background = dataset.frame.iloc[background_indices]
        explained = dataset.frame.iloc[explained_indices]
        explainer = shap.PermutationExplainer(predict, background, seed=2025)
        explanation = explainer(
            explained,
            max_evals=2 * len(feature_names) + 1,
            batch_size=256,
        )
        values = np.asarray(explanation.values)
        importance = np.abs(values).mean(axis=0)
        output_dir = ROOT / "results/real/shap" / name
        output_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            output_dir / "permutation_shap_values.npz",
            values=values,
            base_values=np.asarray(explanation.base_values),
            data=explained.to_numpy(),
            indices=explained_indices,
            feature_names=np.asarray(feature_names),
        )
        pd.DataFrame(
            {"feature": feature_names, "mean_absolute_shap": importance}
        ).sort_values("mean_absolute_shap", ascending=False).to_csv(
            output_dir / "feature_importance.csv", index=False
        )
        group_rows = []
        total = float(importance.sum())
        for group, members in dataset.groups.items():
            group_value = float(sum(importance[feature_names.index(feature)] for feature in members))
            group_rows.append(
                {
                    "feature_group": group,
                    "mean_absolute_shap_sum": group_value,
                    "normalized_contribution_percent": 100.0 * group_value / total,
                }
            )
        pd.DataFrame(group_rows).sort_values(
            "mean_absolute_shap_sum", ascending=False
        ).to_csv(output_dir / "group_importance.csv", index=False)
        print(f"completed SHAP dataset={name} records={len(explained_indices)}")


if __name__ == "__main__":
    main()

