#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.metrics import mean_sd_ci


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="results/real/main_seed_metrics.jsonl")
    parser.add_argument("--output", default="results/real/main_summary.csv")
    args = parser.parse_args()
    input_path = ROOT / args.input
    rows = []
    for line in input_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        record = json.loads(line)
        row = {"dataset": record["dataset"], "model": record["model"], "seed": record["seed"]}
        row.update(record["metrics"])
        rows.append(row)
    frame = pd.DataFrame(rows)
    output_rows = []
    for (dataset, model), group in frame.groupby(["dataset", "model"], sort=False):
        row = {"dataset": dataset, "model": model, "n_seeds": len(group)}
        for metric in ["accuracy", "macro_precision", "macro_recall", "macro_f1", "macro_auc"]:
            summary = mean_sd_ci(group[metric].to_numpy())
            row.update({f"{metric}_{key}": value for key, value in summary.items()})
        output_rows.append(row)
    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(output_rows).to_csv(output_path, index=False)
    print(output_path)


if __name__ == "__main__":
    main()

