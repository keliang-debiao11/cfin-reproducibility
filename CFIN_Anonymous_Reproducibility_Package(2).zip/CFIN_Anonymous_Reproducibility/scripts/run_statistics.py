#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import binomtest
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.delong import paired_delong_test
from cfin_repro.statistics import holm_adjust, paired_stratified_bootstrap_difference


SEEDS = [11, 23, 37, 47, 59, 71, 83, 97, 109, 127]


def load_ensemble(dataset: str, model: str):
    files = [ROOT / f"results/real/{dataset}/{model}/seed_{seed}.predictions.npz" for seed in SEEDS]
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Run all ten seeds before statistical analysis. Missing: {missing}")
    bundles = [np.load(path) for path in files]
    y_true = bundles[0]["y_true"]
    probabilities = np.mean([bundle["probabilities"] for bundle in bundles], axis=0)
    thresholds = [float(bundle["threshold"][0]) for bundle in bundles]
    threshold = None if np.isnan(thresholds).all() else float(np.nanmean(thresholds))
    return y_true, probabilities, threshold


def predictions(probabilities, threshold):
    return (probabilities >= threshold).astype(int) if probabilities.ndim == 1 else probabilities.argmax(axis=1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap-samples", type=int, default=10000)
    args = parser.parse_args()
    output_rows = []
    for dataset in ["inels", "uci"]:
        y_true, cfin_prob, cfin_threshold = load_ensemble(dataset, "cfin")
        y_other, ft_prob, ft_threshold = load_ensemble(dataset, "ft_transformer")
        if not np.array_equal(y_true, y_other):
            raise ValueError("Prediction files do not share the same test-label order")
        cfin_pred = predictions(cfin_prob, cfin_threshold)
        ft_pred = predictions(ft_prob, ft_threshold)

        discordant_a = int(np.sum((cfin_pred == y_true) & (ft_pred != y_true)))
        discordant_b = int(np.sum((cfin_pred != y_true) & (ft_pred == y_true)))
        mcnemar_p = float(binomtest(min(discordant_a, discordant_b), discordant_a + discordant_b, 0.5).pvalue)
        accuracy_metric = lambda y, s: accuracy_score(y, predictions(s, cfin_threshold))
        accuracy_metric_ft = lambda y, s: accuracy_score(y, predictions(s, ft_threshold))
        acc_diff, acc_low, acc_high, _ = paired_stratified_bootstrap_difference(
            y_true, cfin_prob, ft_prob, accuracy_metric, metric_b=accuracy_metric_ft, samples=args.bootstrap_samples
        )
        output_rows.append({"dataset": dataset, "metric": "Accuracy", "difference": acc_diff, "ci_low": acc_low, "ci_high": acc_high, "test": "Exact McNemar", "raw_p": mcnemar_p})

        f1_metric = lambda y, s: f1_score(y, predictions(s, cfin_threshold), average="macro")
        f1_metric_ft = lambda y, s: f1_score(y, predictions(s, ft_threshold), average="macro")
        f1_diff, f1_low, f1_high, f1_p = paired_stratified_bootstrap_difference(
            y_true, cfin_prob, ft_prob, f1_metric, metric_b=f1_metric_ft, samples=args.bootstrap_samples
        )
        output_rows.append({"dataset": dataset, "metric": "Macro-F1", "difference": f1_diff, "ci_low": f1_low, "ci_high": f1_high, "test": "Paired bootstrap", "raw_p": f1_p})

        if dataset == "inels":
            auc_diff, auc_se, auc_p = paired_delong_test(y_true, cfin_prob, ft_prob)
            auc_low, auc_high = auc_diff - 1.96 * auc_se, auc_diff + 1.96 * auc_se
            test = "DeLong"
        else:
            auc_metric = lambda y, s: roc_auc_score(y, s, multi_class="ovr", average="macro")
            auc_diff, auc_low, auc_high, auc_p = paired_stratified_bootstrap_difference(
                y_true, cfin_prob, ft_prob, auc_metric, samples=args.bootstrap_samples
            )
            test = "Paired bootstrap"
        output_rows.append({"dataset": dataset, "metric": "Macro-AUC", "difference": auc_diff, "ci_low": auc_low, "ci_high": auc_high, "test": test, "raw_p": auc_p})

    for dataset in ["inels", "uci"]:
        indices = [i for i, row in enumerate(output_rows) if row["dataset"] == dataset]
        adjusted = holm_adjust([output_rows[i]["raw_p"] for i in indices])
        for index, value in zip(indices, adjusted):
            output_rows[index]["holm_adjusted_p"] = float(value)
    path = ROOT / "results/real/paired_statistics.json"
    path.write_text(json.dumps(output_rows, indent=2, sort_keys=True), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()

