#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "MANIFEST.sha256"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


files = sorted(
    path
    for path in ROOT.rglob("*")
    if path.is_file()
    and path != OUTPUT
    and "__pycache__" not in path.parts
    and path.suffix != ".pyc"
)
OUTPUT.write_text(
    "".join(f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}\n" for path in files),
    encoding="utf-8",
)
print(f"wrote {OUTPUT} with {len(files)} entries")

