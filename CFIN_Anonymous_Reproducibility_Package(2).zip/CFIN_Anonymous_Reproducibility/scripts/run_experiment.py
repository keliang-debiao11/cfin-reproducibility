#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.config import resolved_experiment_config
from cfin_repro.experiment import append_jsonl, dry_run_plan, run_single
from cfin_repro.tuning import tune


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/experiments/main.yaml")
    parser.add_argument("--dataset", choices=["inels", "uci"])
    parser.add_argument(
        "--model",
        choices=["logistic_regression", "random_forest", "mlp", "xgboost", "tabnet", "ft_transformer", "cfin"],
    )
    parser.add_argument("--seed", type=int)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--skip-tuning", action="store_true")
    parser.add_argument("--tuning-trials", type=int)
    args = parser.parse_args()

    if args.dry_run:
        print(json.dumps(dry_run_plan(args.config), indent=2, sort_keys=True))
        return

    config = resolved_experiment_config(args.config)
    datasets = [args.dataset] if args.dataset else config["experiment"]["datasets"]
    models = [args.model] if args.model else config["experiment"]["models"]
    seeds = [args.seed] if args.seed is not None else config["experiment"]["final_seeds"]
    output = ROOT / "results/real/main_seed_metrics.jsonl"
    if output.exists() and args.dataset is None and args.model is None and args.seed is None:
        output.unlink()

    for dataset in datasets:
        for model in models:
            parameters = None
            if not args.skip_tuning:
                tuning = tune(
                    args.config,
                    dataset,
                    model,
                    trials=args.tuning_trials,
                )
                parameters = tuning["best_parameters"]
            for seed in seeds:
                record = run_single(
                    args.config,
                    dataset,
                    model,
                    seed,
                    parameters=parameters,
                )
                append_jsonl(output, record)
                print(
                    f"completed dataset={dataset} model={model} seed={seed} "
                    f"macro_f1={record['metrics']['macro_f1']:.6f} "
                    f"macro_auc={record['metrics']['macro_auc']:.6f}"
                )


if __name__ == "__main__":
    main()

