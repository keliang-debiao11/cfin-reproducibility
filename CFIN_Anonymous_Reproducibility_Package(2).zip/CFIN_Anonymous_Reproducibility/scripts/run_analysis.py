#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.analysis import analysis_plan, run_analysis


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--analysis", choices=["temporal", "school", "ablation", "grouping", "shap", "efficiency", "statistics"], required=True)
    parser.add_argument("--config", default="configs/experiments/main.yaml")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.dry_run:
        print(json.dumps(analysis_plan(args.analysis, args.config), indent=2, sort_keys=True))
        return
    records = run_analysis(args.analysis, args.config)
    print(json.dumps({"analysis": args.analysis, "completed_records": len(records)}, indent=2))


if __name__ == "__main__":
    main()

