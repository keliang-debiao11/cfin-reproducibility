#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.data import load_dataset, save_prepared_dataset


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["inels", "uci", "all"], default="all")
    parser.add_argument("--skip-count-validation", action="store_true")
    args = parser.parse_args()
    names = ["inels", "uci"] if args.dataset == "all" else [args.dataset]
    for name in names:
        dataset = load_dataset(name, validate_counts=not args.skip_count_validation)
        manifest = save_prepared_dataset(dataset)
        print(json.dumps({k: v for k, v in manifest.items() if not k.endswith("indices")}, indent=2))


if __name__ == "__main__":
    main()

