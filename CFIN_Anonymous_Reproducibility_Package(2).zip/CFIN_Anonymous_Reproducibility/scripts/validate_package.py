#!/usr/bin/env python3
from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.provenance import SIMULATED_MARKER
from cfin_repro.reference_results import MAIN_RESULTS


REQUIRED = [
    "README.md", "REPRODUCIBILITY.md", "SIMULATED_LOGS_NOTICE.md", "ANONYMITY_CHECKLIST.md",
    "requirements.txt", "environment.yml", "pyproject.toml",
    "configs/experiments/main.yaml", "configs/models/cfin.yaml", "configs/models/baselines.yaml",
    "configs/datasets/inels.yaml", "configs/datasets/uci.yaml", "configs/analyses.yaml",
    "scripts/prepare_data.py", "scripts/run_experiment.py", "scripts/run_analysis.py",
    "scripts/run_shap.py", "scripts/run_efficiency.py", "scripts/run_statistics.py",
    "scripts/summarize_results.py", "scripts/generate_reference_logs.py", "scripts/build_manifest.py",
    "results/simulated_reference/main_seed_metrics.jsonl",
]


def fail(message: str) -> None:
    raise SystemExit(f"VALIDATION FAILED: {message}")


def check_files() -> None:
    missing = [path for path in REQUIRED if not (ROOT / path).exists()]
    if missing:
        fail(f"missing required files: {missing}")


def check_python_syntax() -> None:
    for path in list((ROOT / "src").rglob("*.py")) + list((ROOT / "scripts").glob("*.py")):
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as exc:
            fail(f"syntax error in {path.relative_to(ROOT)}: {exc}")


def check_anonymity() -> None:
    forbidden = [
        r"Tianpei\s+Xu", r"Zhuo\s+Wang", r"Xuelian\s+Bao", r"Hulunbuir\s+University",
        r"goodluck" + r"1105s", r"@163\.com",
    ]
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".zip", ".png", ".pdf", ".pyc"}:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pattern in forbidden:
            if re.search(pattern, text, flags=re.I):
                fail(f"identifying text matched {pattern!r} in {path.relative_to(ROOT)}")


def check_configs() -> None:
    for name in ["inels", "uci"]:
        spec = yaml.safe_load((ROOT / f"configs/datasets/{name}.yaml").read_text())
        assigned = [feature for members in spec["groups"].values() for feature in members]
        if len(assigned) != len(set(assigned)):
            fail(f"duplicate feature assignment in {name} groups")
        modeled = set(spec["categorical_features"]) | set(spec["numeric_features"])
        if name == "inels":
            modeled |= {f"{x}_missing" for x in spec["missing_indicators"]}
        if set(assigned) != modeled:
            fail(f"grouped features and modeled features differ for {name}")


def check_simulated_boundaries() -> None:
    simulated_files = [
        path for base in [ROOT / "logs/simulated_reference", ROOT / "results/simulated_reference"]
        for path in base.rglob("*") if path.is_file()
    ]
    for path in simulated_files:
        if SIMULATED_MARKER not in path.read_text(encoding="utf-8", errors="ignore"):
            fail(f"simulated provenance marker missing from {path.relative_to(ROOT)}")
    for base in [ROOT / "logs/real", ROOT / "results/real"]:
        for path in base.rglob("*"):
            if path.is_file() and SIMULATED_MARKER in path.read_text(encoding="utf-8", errors="ignore"):
                fail(f"simulated output found in real-output directory: {path.relative_to(ROOT)}")


def check_reference_arithmetic() -> None:
    path = ROOT / "results/simulated_reference/main_seed_metrics.jsonl"
    records = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    if len(records) != 140:
        fail(f"expected 140 simulated seed records, found {len(records)}")
    for (dataset, model), expected in MAIN_RESULTS.items():
        selected = [record for record in records if record["dataset"] == dataset and record["model"] == model]
        if len(selected) != 10:
            fail(f"expected ten records for {dataset}/{model}")
        for metric, (target_mean, target_sd) in expected.items():
            values = np.asarray([record["metrics"][metric] for record in selected])
            if abs(values.mean() - target_mean) > 2e-6 or abs(values.std(ddof=1) - target_sd) > 2e-6:
                fail(f"reference arithmetic mismatch for {dataset}/{model}/{metric}")


def main() -> None:
    check_files()
    check_python_syntax()
    check_anonymity()
    check_configs()
    check_simulated_boundaries()
    check_reference_arithmetic()
    print("VALIDATION PASS")
    print("anonymous text audit: pass")
    print("configuration and group partitions: pass")
    print("simulated/real output boundary: pass")
    print("140 reference seed records and manuscript aggregates: pass")
    print("Python syntax: pass")


if __name__ == "__main__":
    main()

