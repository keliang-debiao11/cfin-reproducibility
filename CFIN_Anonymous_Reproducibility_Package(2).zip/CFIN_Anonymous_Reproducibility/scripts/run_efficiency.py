#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.adapters import fit_predict
from cfin_repro.config import resolved_experiment_config
from cfin_repro.data import fixed_split_indices, load_dataset
from cfin_repro.experiment import _default_parameters, encode_target


def synchronize() -> None:
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.synchronize()
    except ImportError:
        pass


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/experiments/main.yaml")
    parser.add_argument("--warmup", type=int, default=100)
    parser.add_argument("--passes", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=11)
    args = parser.parse_args()
    config = resolved_experiment_config(args.config)
    output = ROOT / "results/real/efficiency.jsonl"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("", encoding="utf-8")

    for dataset_name in config["experiment"]["datasets"]:
        dataset = load_dataset(dataset_name)
        target, _ = encode_target(dataset_name, dataset.target)
        train_indices, test_indices = fixed_split_indices(dataset.target, seed=2025, test_size=0.20)
        for model_name in config["experiment"]["models"]:
            parameters = _default_parameters(model_name, config) if model_name != "tabnet" else {
                "n_d": 32, "n_a": 32, "n_steps": 4, "gamma": 1.5,
                "lambda_sparse": 1e-4, "learning_rate": 1e-4, "weight_decay": 1e-4,
                "batch_size": 256, "focal_gamma": 2.0,
            }
            start = time.perf_counter()
            fitted = fit_predict(
                model_name, parameters, dataset, train_indices, test_indices, target, seed=args.seed
            )
            training_seconds = time.perf_counter() - start
            preprocessor = fitted.preprocessor
            model = fitted.fitted_model
            records = {}
            for batch_size in [1, 256]:
                local = test_indices[: min(batch_size, len(test_indices))]
                frame = dataset.frame.iloc[local]
                if model_name in {"logistic_regression", "random_forest", "xgboost", "tabnet"}:
                    features = preprocessor.transform_dense(frame)
                    callable_ = lambda: model.predict_proba(features)
                elif model_name == "mlp":
                    import torch
                    features = torch.from_numpy(preprocessor.transform_dense(frame)).to(
                        next(model.parameters()).device
                    )
                    callable_ = lambda: model(features)
                else:
                    import torch
                    arrays = preprocessor.transform_neural(frame)
                    numerical = torch.from_numpy(arrays.numerical).to(next(model.parameters()).device)
                    categorical = torch.from_numpy(arrays.categorical).to(next(model.parameters()).device)
                    callable_ = lambda: model(numerical, categorical)
                for _ in range(args.warmup):
                    callable_()
                samples = []
                for _ in range(args.passes):
                    synchronize()
                    tick = time.perf_counter_ns()
                    callable_()
                    synchronize()
                    samples.append((time.perf_counter_ns() - tick) / 1e6)
                records[batch_size] = float(np.median(samples)) / batch_size
            if hasattr(model, "parameters"):
                complexity = {
                    "unit": "parameters",
                    "value": int(sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)),
                }
            else:
                complexity = {"unit": "serialized_bytes", "value": len(pickle.dumps(model))}
            record = {
                "provenance": "REAL_EXECUTION",
                "dataset": dataset_name,
                "model": model_name,
                "seed": args.seed,
                "training_time_s": training_seconds,
                "batch1_latency_ms": records[1],
                "batch256_per_student_latency_ms": records[256],
                "complexity": complexity,
            }
            with output.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, sort_keys=True) + "\n")
            print(f"completed efficiency dataset={dataset_name} model={model_name}")


if __name__ == "__main__":
    main()

