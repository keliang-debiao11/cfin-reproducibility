#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cfin_repro.provenance import SIMULATED_MARKER
from cfin_repro.reference_results import (
    ABLATION,
    EFFICIENCY,
    MAIN_RESULTS,
    PAIRED_TESTS,
    SCHOOL,
    SEEDS,
    SHAP_FEATURES,
    SHAP_GROUPS,
    TEMPORAL,
    THRESHOLDS,
)


RESULT_DIR = ROOT / "results/simulated_reference"
LOG_DIR = ROOT / "logs/simulated_reference"


def standardized_pattern(key: str) -> np.ndarray:
    base = np.asarray([-1.5, -1.2, -0.9, -0.5, -0.2, 0.2, 0.5, 0.9, 1.2, 1.5])
    base = (base - base.mean()) / base.std(ddof=1)
    shift = int(hashlib.sha256(key.encode()).hexdigest()[:4], 16) % len(base)
    return np.roll(base, shift)


def values(mean: float, sd: float, key: str, decimals: int = 6) -> list[float]:
    return np.round(mean + sd * standardized_pattern(key), decimals).tolist()


def write_csv(name: str, header: list[str], rows: list[tuple | list]) -> None:
    path = RESULT_DIR / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["provenance", *header])
        for row in rows:
            writer.writerow([SIMULATED_MARKER, *row])


def main_results() -> None:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    records = []
    thresholds_by_model = {
        model: values(mean, sd, f"threshold-{model}", decimals=4)
        for model, (mean, sd) in THRESHOLDS.items()
    }
    for (dataset, model), metrics in MAIN_RESULTS.items():
        per_metric = {
            metric: values(mean, sd, f"{dataset}-{model}-{metric}")
            for metric, (mean, sd) in metrics.items()
        }
        for index, seed in enumerate(SEEDS):
            record = {
                "provenance": SIMULATED_MARKER,
                "dataset": dataset,
                "model": model,
                "seed": seed,
                "threshold": thresholds_by_model[model][index] if dataset == "inels" else None,
                "metrics": {metric: series[index] for metric, series in per_metric.items()},
            }
            records.append(record)
    path = RESULT_DIR / "main_seed_metrics.jsonl"
    with path.open("w", encoding="utf-8") as stream:
        for record in records:
            stream.write(json.dumps(record, sort_keys=True) + "\n")

    summary_rows = []
    for (dataset, model), metrics in MAIN_RESULTS.items():
        summary_rows.append(
            [dataset, model]
            + [item for metric in ["accuracy", "macro_precision", "macro_recall", "macro_f1", "macro_auc"] for item in metrics[metric]]
        )
    write_csv(
        "main_summary.csv",
        [
            "dataset", "model", "accuracy_mean", "accuracy_sd",
            "macro_precision_mean", "macro_precision_sd", "macro_recall_mean", "macro_recall_sd",
            "macro_f1_mean", "macro_f1_sd", "macro_auc_mean", "macro_auc_sd",
        ],
        summary_rows,
    )
    threshold_rows = []
    for model, (mean, sd) in THRESHOLDS.items():
        for seed, threshold in zip(SEEDS, thresholds_by_model[model]):
            threshold_rows.append((model, seed, threshold, mean, sd))
    write_csv(
        "oof_thresholds.csv",
        ["model", "seed", "selected_threshold", "reported_mean", "reported_sd"],
        threshold_rows,
    )


def analysis_tables() -> None:
    write_csv(
        "temporal_horizons.csv",
        ["dataset", "horizon", "included_information", "macro_f1_mean", "macro_f1_sd", "macro_auc_mean", "macro_auc_sd"],
        TEMPORAL,
    )
    write_csv(
        "school_sensitivity.csv",
        ["model", "evaluation_split", "predictor_set", "macro_f1_mean", "macro_f1_sd", "macro_auc_mean", "macro_auc_sd"],
        SCHOOL,
    )
    write_csv("ablation_grouping.csv", ["variant", "macro_f1_mean", "macro_f1_sd"], ABLATION)
    write_csv(
        "paired_tests.csv",
        ["dataset", "metric", "difference", "ci_low", "ci_high", "test", "raw_p", "holm_adjusted_p"],
        PAIRED_TESTS,
    )
    shap_rows = []
    for dataset, entries in SHAP_FEATURES.items():
        for rank, (feature, importance) in enumerate(entries, 1):
            shap_rows.append((dataset, rank, feature, importance))
    write_csv("shap_feature_importance.csv", ["dataset", "rank", "feature", "mean_absolute_shap"], shap_rows)
    write_csv(
        "shap_group_importance.csv",
        ["dataset", "feature_group", "mean_absolute_shap", "normalized_contribution_percent"],
        SHAP_GROUPS,
    )
    write_csv(
        "efficiency.csv",
        ["model", "dataset", "complexity", "training_time_s", "batch1_latency_ms", "batch256_per_student_latency_ms"],
        EFFICIENCY,
    )


def logs() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    banner = (
        f"PROVENANCE={SIMULATED_MARKER}\n"
        "NOTICE=This is a synthetic schema example, not a real execution log.\n"
    )
    (LOG_DIR / "run_manifest.log").write_text(
        banner
        + "split_seed=2025\ncv_folds=5\ntuning_trials=100\n"
        + f"final_seeds={SEEDS}\nmodels=7\ndatasets=2\nplanned_final_runs=140\n",
        encoding="utf-8",
    )
    tuning_lines = [banner]
    for dataset in ["inels", "uci"]:
        for model in ["logistic_regression", "random_forest", "mlp", "xgboost", "tabnet", "ft_transformer", "cfin"]:
            tuning_lines.append(
                f"dataset={dataset} model={model} trials=100 folds=5 status=SIMULATED_REFERENCE_ONLY\n"
            )
    (LOG_DIR / "tuning_summary.log").write_text("".join(tuning_lines), encoding="utf-8")

    validation_text = banner + (
        "dataset=INELS total=19100 train=15280 test=3820 "
        "train_counts=Retained:14560,Dropout:720 test_counts=Retained:3640,Dropout:180\n"
        "dataset=UCI total=4424 train=3539 test=885 "
        "train_counts=Graduate:1767,Dropout:1137,Enrolled:635 "
        "test_counts=Graduate:442,Dropout:284,Enrolled:159\n"
    )
    (LOG_DIR / "dataset_validation.log").write_text(validation_text, encoding="utf-8")

    threshold_lines = [banner]
    for model, (mean, sd) in THRESHOLDS.items():
        series = values(mean, sd, f"threshold-{model}", decimals=4)
        for seed, threshold in zip(SEEDS, series):
            threshold_lines.append(
                f"dataset=inels model={model} seed={seed} source=5fold_oof "
                f"selected_threshold={threshold:.4f} status=SIMULATED_REFERENCE_ONLY\n"
            )
    (LOG_DIR / "oof_threshold_selection.log").write_text(
        "".join(threshold_lines), encoding="utf-8"
    )

    tuning_path = LOG_DIR / "tuning_trials.jsonl"
    with tuning_path.open("w", encoding="utf-8") as stream:
        for dataset in ["inels", "uci"]:
            for model in ["logistic_regression", "random_forest", "mlp", "xgboost", "tabnet", "ft_transformer", "cfin"]:
                best_target = MAIN_RESULTS[(dataset, model)]["macro_f1"][0] - 0.004
                rng = np.random.default_rng(
                    int(hashlib.sha256(f"{dataset}-{model}".encode()).hexdigest()[:8], 16)
                )
                running_best = 0.0
                for trial in range(100):
                    progress = 1.0 - np.exp(-(trial + 1) / 24.0)
                    score = best_target - 0.08 * (1.0 - progress) + rng.normal(0.0, 0.004)
                    running_best = max(running_best, score)
                    stream.write(
                        json.dumps(
                            {
                                "provenance": SIMULATED_MARKER,
                                "dataset": dataset,
                                "model": model,
                                "trial": trial,
                                "validation_macro_f1": round(float(score), 6),
                                "running_best_macro_f1": round(float(running_best), 6),
                                "folds": 5,
                                "status": "SIMULATED_REFERENCE_ONLY",
                            },
                            sort_keys=True,
                        )
                        + "\n"
                    )

    for dataset in ["inels", "uci"]:
        target_mean = MAIN_RESULTS[(dataset, "cfin")]["macro_f1"][0]
        for seed_index, seed in enumerate(SEEDS):
            best_epoch = 68 + (seed_index * 7) % 29
            epochs_run = best_epoch + 20
            lines = [banner, f"dataset={dataset} model=cfin seed={seed}\n"]
            for epoch in range(1, epochs_run + 1):
                progress = 1.0 - np.exp(-epoch / 22.0)
                val_f1 = target_mean - 0.18 * (1.0 - progress) + 0.002 * np.sin(epoch + seed)
                train_loss = 0.72 * np.exp(-epoch / 35.0) + 0.08
                lines.append(
                    f"epoch={epoch:03d} train_loss={train_loss:.6f} val_macro_f1={val_f1:.6f}\n"
                )
            lines.append(
                f"best_epoch={best_epoch} early_stopping_patience=20 status=SIMULATED_REFERENCE_ONLY\n"
            )
            (LOG_DIR / f"cfin_{dataset}_seed_{seed}.log").write_text(
                "".join(lines), encoding="utf-8"
            )

    provenance = {
        "provenance": SIMULATED_MARKER,
        "simulated": True,
        "purpose": "schema validation and AI reproduction guidance",
        "must_be_replaced_by_real_execution": True,
    }
    (LOG_DIR / "provenance.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True), encoding="utf-8"
    )


if __name__ == "__main__":
    main_results()
    analysis_tables()
    logs()
    print(f"Generated simulated reference outputs under {RESULT_DIR} and {LOG_DIR}")

