from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from .config import PROJECT_ROOT, dataset_config


@dataclass(frozen=True)
class PreparedDataset:
    name: str
    frame: pd.DataFrame
    target: pd.Series
    target_name: str
    groups: dict[str, list[str]]
    categorical_features: list[str]
    numeric_features: list[str]
    school_ids: pd.Series | None = None


def _resolve_one(columns: list[str], aliases: list[str], field: str) -> str:
    exact = [alias for alias in aliases if alias in columns]
    if len(exact) == 1:
        return exact[0]
    lower_map = {column.strip().lower(): column for column in columns}
    relaxed = [lower_map[a.strip().lower()] for a in aliases if a.strip().lower() in lower_map]
    relaxed = list(dict.fromkeys(relaxed))
    if len(relaxed) == 1:
        return relaxed[0]
    raise ValueError(
        f"Cannot uniquely resolve '{field}'. Aliases={aliases}; matches={exact or relaxed}; "
        f"available columns={columns}"
    )


def _resolve_optional(columns: list[str], aliases: list[str]) -> str | None:
    try:
        return _resolve_one(columns, aliases, "optional field")
    except ValueError:
        return None


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Raw dataset not found: {path}. See data/README.md for placement instructions."
        )
    attempts = [
        {"sep": None, "engine": "python"},
        {"sep": ";"},
        {"sep": ","},
    ]
    last_error: Exception | None = None
    for kwargs in attempts:
        try:
            frame = pd.read_csv(path, **kwargs)
            if frame.shape[1] > 1:
                return frame
        except Exception as exc:  # pragma: no cover - diagnostic fallbacks
            last_error = exc
    raise ValueError(f"Unable to parse {path}: {last_error}")


def _rename_features(frame: pd.DataFrame, spec: dict[str, Any]) -> pd.DataFrame:
    rename: dict[str, str] = {}
    for canonical, aliases in spec["features"].items():
        rename[_resolve_one(list(frame.columns), aliases, canonical)] = canonical
    target_column = _resolve_one(list(frame.columns), spec["target_aliases"], "target")
    rename[target_column] = "target"
    return frame.rename(columns=rename)


def _prepare_inels(frame: pd.DataFrame, spec: dict[str, Any]) -> PreparedDataset:
    school_column = _resolve_optional(list(frame.columns), spec["school_id_aliases"])
    school_ids = frame[school_column].copy() if school_column else None
    renamed = _rename_features(frame, spec)
    target = (
        renamed["target"]
        .astype(str)
        .str.strip()
        .str.lower()
        .map({str(k).lower(): v for k, v in spec["label_map"].items()})
    )
    if target.isna().any():
        unknown = sorted(renamed.loc[target.isna(), "target"].astype(str).unique())
        raise ValueError(f"Unrecognized INELS target labels: {unknown}")

    for score in ["mathematics_score", "english_score", "science_score"]:
        renamed[score] = pd.to_numeric(renamed[score], errors="coerce").clip(0.0, 1.0)
    renamed["establishment_year"] = pd.to_numeric(
        renamed["establishment_year"], errors="coerce"
    )
    renamed.loc[renamed["establishment_year"] > 2016, "establishment_year"] = np.nan
    for feature in spec["missing_indicators"]:
        renamed[f"{feature}_missing"] = renamed[feature].isna().astype(np.int8)

    selected = [
        feature
        for members in spec["groups"].values()
        for feature in members
        if feature not in spec["principal_exclusions"]
    ]
    selected = list(dict.fromkeys(selected))
    output = renamed[selected].copy()
    return PreparedDataset(
        name="inels",
        frame=output,
        target=target.rename("target"),
        target_name="target",
        groups={k: [x for x in v if x in output.columns] for k, v in spec["groups"].items()},
        categorical_features=[x for x in spec["categorical_features"] if x in output.columns],
        numeric_features=[x for x in spec["numeric_features"] if x in output.columns]
        + [f"{x}_missing" for x in spec["missing_indicators"]],
        school_ids=school_ids,
    )


def _prepare_uci(frame: pd.DataFrame, spec: dict[str, Any]) -> PreparedDataset:
    renamed = _rename_features(frame, spec)
    target = renamed["target"].astype(str).str.strip()
    allowed = set(spec["label_order"])
    if set(target.unique()) != allowed:
        raise ValueError(f"Unexpected UCI target labels: {sorted(target.unique())}")
    selected = [feature for members in spec["groups"].values() for feature in members]
    selected = list(dict.fromkeys(selected))
    output = renamed[selected].copy()
    return PreparedDataset(
        name="uci",
        frame=output,
        target=target.rename("target"),
        target_name="target",
        groups={k: list(v) for k, v in spec["groups"].items()},
        categorical_features=list(spec["categorical_features"]),
        numeric_features=list(spec["numeric_features"]),
        school_ids=None,
    )


def validate_expected_counts(dataset: PreparedDataset, spec: dict[str, Any]) -> None:
    expected = spec["expected"]
    if len(dataset.frame) != expected["total_records"]:
        raise ValueError(f"Expected {expected['total_records']} records, found {len(dataset.frame)}")
    counts = dataset.target.value_counts().to_dict()
    if counts != expected["target_counts"]:
        raise ValueError(f"Target-count mismatch: expected {expected['target_counts']}, found {counts}")


def load_dataset(name: str, validate_counts: bool = True) -> PreparedDataset:
    spec = dataset_config(name)
    path = PROJECT_ROOT / spec["raw_path"]
    raw = _read_csv(path)
    dataset = _prepare_inels(raw, spec) if name == "inels" else _prepare_uci(raw, spec)
    if validate_counts:
        validate_expected_counts(dataset, spec)
    return dataset


def fixed_split_indices(
    target: pd.Series,
    seed: int = 2025,
    test_size: float = 0.20,
) -> tuple[np.ndarray, np.ndarray]:
    indices = np.arange(len(target))
    train, test = train_test_split(
        indices,
        test_size=test_size,
        random_state=seed,
        stratify=target.to_numpy(),
    )
    return np.sort(train), np.sort(test)


def dataset_fingerprint(dataset: PreparedDataset) -> str:
    digest = hashlib.sha256()
    digest.update(pd.util.hash_pandas_object(dataset.frame, index=True).values.tobytes())
    digest.update(pd.util.hash_pandas_object(dataset.target, index=True).values.tobytes())
    return digest.hexdigest()


def save_prepared_dataset(dataset: PreparedDataset) -> dict[str, Any]:
    spec = dataset_config(dataset.name)
    output_path = PROJECT_ROOT / spec["processed_path"]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    combined = dataset.frame.copy()
    combined["target"] = dataset.target.to_numpy()
    if dataset.school_ids is not None:
        combined["__school_group_key__"] = dataset.school_ids.to_numpy()
    combined.to_csv(output_path, index=False)

    train_idx, test_idx = fixed_split_indices(dataset.target)
    manifest = {
        "dataset": dataset.name,
        "fingerprint_sha256": dataset_fingerprint(dataset),
        "split_seed": 2025,
        "train_indices": train_idx.tolist(),
        "test_indices": test_idx.tolist(),
        "train_target_counts": dataset.target.iloc[train_idx].value_counts().to_dict(),
        "test_target_counts": dataset.target.iloc[test_idx].value_counts().to_dict(),
    }
    manifest_path = output_path.with_suffix(".split.json")
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    return manifest

