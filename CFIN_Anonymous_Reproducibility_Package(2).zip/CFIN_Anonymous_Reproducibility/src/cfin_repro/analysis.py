from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import mutual_info_score
from sklearn.model_selection import StratifiedGroupKFold

from .adapters import fit_predict
from .config import PROJECT_ROOT, resolved_experiment_config
from .data import PreparedDataset, fixed_split_indices, load_dataset
from .experiment import _default_parameters, encode_target, oof_threshold
from .metrics import evaluate_classification
from .thresholds import assert_oof_complete, select_macro_f1_threshold


def _write_jsonl(path: Path, records: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for record in records:
            stream.write(json.dumps(record, sort_keys=True) + "\n")


def subset_dataset(dataset: PreparedDataset, features: list[str]) -> PreparedDataset:
    feature_set = set(features)
    groups = {
        name: [feature for feature in members if feature in feature_set]
        for name, members in dataset.groups.items()
    }
    groups = {name: members for name, members in groups.items() if members}
    return replace(
        dataset,
        frame=dataset.frame[features].copy(),
        groups=groups,
        categorical_features=[x for x in dataset.categorical_features if x in feature_set],
        numeric_features=[x for x in dataset.numeric_features if x in feature_set],
    )


def with_groups(dataset: PreparedDataset, groups: dict[str, list[str]]) -> PreparedDataset:
    assigned = [feature for members in groups.values() for feature in members]
    if len(assigned) != len(set(assigned)) or set(assigned) != set(dataset.frame.columns):
        raise ValueError("Alternative groups must be a complete, non-overlapping partition")
    return replace(dataset, groups=groups)


def evaluate_holdout_variant(
    dataset: PreparedDataset,
    model_name: str,
    parameters: dict[str, Any],
    seeds: list[int],
    variant: str,
) -> list[dict[str, Any]]:
    target, class_order = encode_target(dataset.name, dataset.target)
    train_indices, test_indices = fixed_split_indices(dataset.target, seed=2025, test_size=0.20)
    records = []
    for seed in seeds:
        threshold = None
        if dataset.name == "inels":
            threshold, _ = oof_threshold(
                model_name, parameters, dataset, train_indices, target, seed
            )
        prediction = fit_predict(
            model_name,
            parameters,
            dataset,
            train_indices,
            test_indices,
            target,
            seed=seed,
        )
        records.append(
            {
                "provenance": "REAL_EXECUTION",
                "analysis_variant": variant,
                "dataset": dataset.name,
                "model": model_name,
                "seed": seed,
                "threshold": threshold,
                "metrics": evaluate_classification(
                    target[test_indices],
                    prediction.probabilities,
                    threshold=threshold,
                    labels=list(range(len(class_order))),
                ),
            }
        )
    return records


def run_temporal(config_path: str | Path) -> list[dict[str, Any]]:
    config = resolved_experiment_config(config_path)
    seeds = config["experiment"]["final_seeds"]
    params = _default_parameters("cfin", config)
    records: list[dict[str, Any]] = []

    inels = load_dataset("inels")
    records += evaluate_holdout_variant(inels, "cfin", params, seeds, "INELS_full_retrospective")
    score_excluded = [
        feature for feature in inels.frame.columns if feature not in {"mathematics_score", "english_score"}
    ]
    records += evaluate_holdout_variant(
        subset_dataset(inels, score_excluded), "cfin", params, seeds, "INELS_score_excluded"
    )

    uci = load_dataset("uci")
    uci_spec = config["dataset_specs"]["uci"]
    for horizon, group_names in uci_spec["horizons"].items():
        features = [feature for group in group_names for feature in uci.groups[group]]
        records += evaluate_holdout_variant(
            subset_dataset(uci, features), "cfin", params, seeds, f"UCI_{horizon}"
        )
    _write_jsonl(PROJECT_ROOT / "results/real/analyses/temporal.jsonl", records)
    return records


def run_ablation(config_path: str | Path) -> list[dict[str, Any]]:
    config = resolved_experiment_config(config_path)
    dataset = load_dataset("inels")
    seeds = config["experiment"]["final_seeds"]
    base = _default_parameters("cfin", config)
    variants = {
        "full": {},
        "without_inter_group_context": {"use_context_encoder": False},
        "flat_encoding": {"flat_encoder": True},
        "weighted_cross_entropy": {"loss": "weighted_cross_entropy"},
        "unweighted_cross_entropy": {"loss": "cross_entropy"},
    }
    records: list[dict[str, Any]] = []
    for name, overrides in variants.items():
        parameters = {**base, **overrides}
        records += evaluate_holdout_variant(dataset, "cfin", parameters, seeds, name)
    _write_jsonl(PROJECT_ROOT / "results/real/analyses/ablation.jsonl", records)
    return records


def _discretize_feature(series: pd.Series) -> np.ndarray:
    if pd.api.types.is_numeric_dtype(series) and series.nunique(dropna=True) > 12:
        return pd.qcut(series.rank(method="first"), q=10, labels=False, duplicates="drop").fillna(-1).to_numpy()
    return pd.factorize(series.astype(str), sort=True)[0]


def data_driven_groups(dataset: PreparedDataset, train_indices: np.ndarray, n_groups: int = 4) -> dict[str, list[str]]:
    features = list(dataset.frame.columns)
    values = [_discretize_feature(dataset.frame.iloc[train_indices][feature]) for feature in features]
    similarity = np.eye(len(features), dtype=float)
    for i in range(len(features)):
        for j in range(i + 1, len(features)):
            mi = mutual_info_score(values[i], values[j])
            denom = max(mutual_info_score(values[i], values[i]), mutual_info_score(values[j], values[j]), 1e-12)
            similarity[i, j] = similarity[j, i] = mi / denom
    clustering = AgglomerativeClustering(
        n_clusters=n_groups, metric="precomputed", linkage="average"
    ).fit(1.0 - similarity)
    return {
        f"cluster_{group + 1}": [
            feature for feature, label in zip(features, clustering.labels_) if label == group
        ]
        for group in range(n_groups)
    }


def random_groups(dataset: PreparedDataset, seed: int) -> dict[str, list[str]]:
    names = list(dataset.groups)
    sizes = [len(dataset.groups[name]) for name in names]
    features = np.asarray(list(dataset.frame.columns), dtype=object)
    rng = np.random.default_rng(seed)
    rng.shuffle(features)
    result = {}
    start = 0
    for name, size in zip(names, sizes):
        result[f"random_{name}"] = features[start : start + size].tolist()
        start += size
    return result


def alternative_four_domain(dataset: PreparedDataset) -> dict[str, list[str]]:
    return {
        "learner_background": ["gender", "caste", "guardian_type"],
        "academic_performance": ["mathematics_score", "english_score"],
        "household_resources": ["household_internet_access"],
        "institutional_context": [
            "science_teacher_qualification",
            "language_teacher_qualification",
            "total_students",
            "total_toilets",
            "establishment_year",
            "establishment_year_missing",
            "total_toilets_missing",
        ],
    }


def run_grouping(config_path: str | Path) -> list[dict[str, Any]]:
    config = resolved_experiment_config(config_path)
    dataset = load_dataset("inels")
    train_indices, _ = fixed_split_indices(dataset.target, seed=2025, test_size=0.20)
    params = _default_parameters("cfin", config)
    final_seeds = config["experiment"]["final_seeds"]
    variants: list[tuple[str, PreparedDataset]] = [
        ("semantic", dataset),
        ("data_driven_nmi", with_groups(dataset, data_driven_groups(dataset, train_indices))),
        ("alternative_four_domain", with_groups(dataset, alternative_four_domain(dataset))),
    ]
    for grouping_seed in [101, 202, 303, 404, 505]:
        variants.append(
            (f"random_seed_{grouping_seed}", with_groups(dataset, random_groups(dataset, grouping_seed)))
        )
    records: list[dict[str, Any]] = []
    for name, variant_dataset in variants:
        records += evaluate_holdout_variant(
            variant_dataset, "cfin", params, final_seeds, name
        )
    _write_jsonl(PROJECT_ROOT / "results/real/analyses/grouping.jsonl", records)
    return records


def _grouped_inner_threshold(
    model_name: str,
    parameters: dict[str, Any],
    dataset: PreparedDataset,
    outer_train: np.ndarray,
    target: np.ndarray,
    groups: np.ndarray,
    seed: int,
) -> float:
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
    oof = np.full(len(outer_train), np.nan)
    for train_local, validation_local in splitter.split(
        outer_train, target[outer_train], groups[outer_train]
    ):
        prediction = fit_predict(
            model_name,
            parameters,
            dataset,
            outer_train[train_local],
            outer_train[validation_local],
            target,
            seed=seed,
        )
        oof[validation_local] = np.asarray(prediction.probabilities).reshape(-1)
    assert_oof_complete(oof)
    threshold, _ = select_macro_f1_threshold(target[outer_train], oof)
    return threshold


def run_school(config_path: str | Path) -> list[dict[str, Any]]:
    config = resolved_experiment_config(config_path)
    base_dataset = load_dataset("inels")
    if base_dataset.school_ids is None:
        raise ValueError("School-grouped analysis requires a resolvable school identifier column")
    target, class_order = encode_target("inels", base_dataset.target)
    all_indices = np.arange(len(target))
    school_ids = base_dataset.school_ids.to_numpy()
    exclusions = set(config["dataset_specs"]["inels"]["school_context_exclusions"])
    variants = {
        "full_features": base_dataset,
        "school_context_excluded": subset_dataset(
            base_dataset, [feature for feature in base_dataset.frame.columns if feature not in exclusions]
        ),
    }
    records: list[dict[str, Any]] = []
    for model_name in ["ft_transformer", "cfin"]:
        parameters = _default_parameters(model_name, config)
        for predictor_set, dataset in variants.items():
            for seed in config["experiment"]["final_seeds"]:
                outer = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed)
                probabilities = np.full(len(target), np.nan)
                fold_thresholds = []
                for outer_train_local, outer_validation_local in outer.split(
                    all_indices, target, school_ids
                ):
                    threshold = _grouped_inner_threshold(
                        model_name,
                        parameters,
                        dataset,
                        outer_train_local,
                        target,
                        school_ids,
                        seed,
                    )
                    fold_thresholds.append(threshold)
                    prediction = fit_predict(
                        model_name,
                        parameters,
                        dataset,
                        outer_train_local,
                        outer_validation_local,
                        target,
                        seed=seed,
                    )
                    probabilities[outer_validation_local] = np.asarray(
                        prediction.probabilities
                    ).reshape(-1)
                assert_oof_complete(probabilities)
                records.append(
                    {
                        "provenance": "REAL_EXECUTION",
                        "analysis_variant": "school_grouped_five_fold",
                        "predictor_set": predictor_set,
                        "model": model_name,
                        "seed": seed,
                        "fold_thresholds": fold_thresholds,
                        "metrics": evaluate_classification(
                            target,
                            probabilities,
                            threshold=float(np.mean(fold_thresholds)),
                            labels=list(range(len(class_order))),
                        ),
                    }
                )
    _write_jsonl(PROJECT_ROOT / "results/real/analyses/school.jsonl", records)
    return records


def analysis_plan(name: str, config_path: str | Path) -> dict[str, Any]:
    config = resolved_experiment_config(config_path)
    if name not in config["analyses"]:
        raise ValueError(f"Unknown analysis: {name}")
    return {
        "analysis": name,
        "specification": config["analyses"][name],
        "output_root": str(PROJECT_ROOT / "results/real/analyses"),
        "provenance": "PLANNED_REAL_EXECUTION",
    }


def run_analysis(name: str, config_path: str | Path) -> list[dict[str, Any]]:
    if name == "temporal":
        return run_temporal(config_path)
    if name == "ablation":
        return run_ablation(config_path)
    if name == "grouping":
        return run_grouping(config_path)
    if name == "school":
        return run_school(config_path)
    if name in {"shap", "efficiency", "statistics"}:
        raise ValueError(
            f"Use scripts/run_{name}.py for {name}; it requires fitted predictions or model checkpoints."
        )
    raise ValueError(name)

