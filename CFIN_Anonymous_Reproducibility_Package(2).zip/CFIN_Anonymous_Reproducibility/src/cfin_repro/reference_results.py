from __future__ import annotations


SEEDS = [11, 23, 37, 47, 59, 71, 83, 97, 109, 127]

MAIN_RESULTS = {
    ("inels", "logistic_regression"): {"accuracy": (.850, .003), "macro_precision": (.713, .006), "macro_recall": (.706, .008), "macro_f1": (.709, .007), "macro_auc": (.786, .005)},
    ("inels", "random_forest"): {"accuracy": (.894, .003), "macro_precision": (.752, .006), "macro_recall": (.747, .007), "macro_f1": (.749, .006), "macro_auc": (.833, .005)},
    ("inels", "mlp"): {"accuracy": (.903, .004), "macro_precision": (.783, .008), "macro_recall": (.776, .009), "macro_f1": (.779, .008), "macro_auc": (.861, .007)},
    ("inels", "xgboost"): {"accuracy": (.906, .003), "macro_precision": (.786, .005), "macro_recall": (.779, .006), "macro_f1": (.782, .005), "macro_auc": (.867, .004)},
    ("inels", "tabnet"): {"accuracy": (.908, .004), "macro_precision": (.794, .007), "macro_recall": (.798, .008), "macro_f1": (.792, .007), "macro_auc": (.878, .006)},
    ("inels", "ft_transformer"): {"accuracy": (.910, .003), "macro_precision": (.803, .006), "macro_recall": (.797, .007), "macro_f1": (.800, .006), "macro_auc": (.882, .005)},
    ("inels", "cfin"): {"accuracy": (.923, .003), "macro_precision": (.839, .006), "macro_recall": (.831, .007), "macro_f1": (.835, .006), "macro_auc": (.910, .004)},
    ("uci", "logistic_regression"): {"accuracy": (.719, .006), "macro_precision": (.712, .009), "macro_recall": (.715, .010), "macro_f1": (.713, .009), "macro_auc": (.793, .007)},
    ("uci", "random_forest"): {"accuracy": (.753, .005), "macro_precision": (.737, .008), "macro_recall": (.752, .009), "macro_f1": (.740, .008), "macro_auc": (.829, .007)},
    ("uci", "mlp"): {"accuracy": (.780, .007), "macro_precision": (.763, .010), "macro_recall": (.770, .011), "macro_f1": (.765, .009), "macro_auc": (.846, .008)},
    ("uci", "xgboost"): {"accuracy": (.783, .005), "macro_precision": (.768, .007), "macro_recall": (.775, .008), "macro_f1": (.771, .007), "macro_auc": (.851, .006)},
    ("uci", "tabnet"): {"accuracy": (.788, .007), "macro_precision": (.773, .009), "macro_recall": (.780, .010), "macro_f1": (.776, .009), "macro_auc": (.865, .008)},
    ("uci", "ft_transformer"): {"accuracy": (.803, .006), "macro_precision": (.788, .008), "macro_recall": (.796, .009), "macro_f1": (.791, .008), "macro_auc": (.878, .007)},
    ("uci", "cfin"): {"accuracy": (.875, .005), "macro_precision": (.842, .007), "macro_recall": (.839, .008), "macro_f1": (.840, .007), "macro_auc": (.918, .005)},
}

THRESHOLDS = {
    "logistic_regression": (.58, .02),
    "random_forest": (.46, .03),
    "mlp": (.64, .02),
    "xgboost": (.61, .02),
    "tabnet": (.65, .02),
    "ft_transformer": (.66, .02),
    "cfin": (.68, .02),
}

TEMPORAL = [
    ("INELS", "Full retrospective", "All retained predictors", .835, .006, .910, .004),
    ("INELS", "Score-excluded", "Excludes mathematics, English, and science scores", .748, .009, .821, .007),
    ("UCI", "T0", "Enrolment-time predictors", .693, .010, .798, .008),
    ("UCI", "T1", "T0 plus first-semester records", .789, .009, .873, .007),
    ("UCI", "T2", "T1 plus second-semester records", .840, .007, .918, .005),
]

SCHOOL = [
    ("CFIN", "Random student-level split", "Full features", .835, .006, .910, .004),
    ("CFIN", "Random student-level split", "School context excluded", .807, .008, .886, .006),
    ("FT-Transformer", "School-grouped five-fold validation", "Full features", .766, .013, .842, .011),
    ("CFIN", "School-grouped five-fold validation", "Full features", .794, .012, .868, .009),
    ("FT-Transformer", "School-grouped five-fold validation", "School context excluded", .754, .014, .830, .012),
    ("CFIN", "School-grouped five-fold validation", "School context excluded", .783, .013, .855, .010),
]

ABLATION = [
    ("CFIN full model", .835, .006),
    ("Without inter-group context encoder", .798, .007),
    ("Flat encoding without feature groups", .772, .008),
    ("Weighted cross-entropy instead of focal loss", .810, .007),
    ("Unweighted cross-entropy", .771, .009),
    ("Random grouping", .793, .010),
    ("Data-driven grouping", .824, .007),
    ("Alternative four-domain grouping", .833, .006),
]

PAIRED_TESTS = [
    ("INELS", "Accuracy", .013, .007, .019, "Exact McNemar", .0031, .0031),
    ("INELS", "Macro-F1", .035, .028, .042, "Paired bootstrap", .0004, .0012),
    ("INELS", "Macro-AUC", .028, .021, .035, "DeLong", .0006, .0012),
    ("UCI", "Accuracy", .072, .059, .085, "Exact McNemar", .0003, .0004),
    ("UCI", "Macro-F1", .049, .038, .060, "Paired bootstrap", .0001, .0003),
    ("UCI", "Macro-AUC", .040, .031, .049, "Paired bootstrap", .0002, .0004),
]

SHAP_FEATURES = {
    "INELS": [
        ("Mathematics score", .181), ("English score", .153), ("Caste: OBC", .099),
        ("Total number of students", .086), ("Household internet access", .073),
        ("Gender", .072), ("Establishment year", .052), ("Guardian type", .043),
        ("Language-teacher qualification", .039), ("Total toilets", .031),
        ("Science-teacher qualification", .028), ("Establishment year missing", .007),
        ("Total toilets missing", .005),
    ],
    "UCI": [
        ("Curricular units 2nd semester: approved", .214),
        ("Curricular units 2nd semester: grade", .187),
        ("Curricular units 1st semester: approved", .142),
        ("Tuition fees up to date", .104),
        ("Curricular units 1st semester: grade", .091),
        ("Age at enrolment", .028), ("Admission grade", .026),
        ("Gross domestic product", .024), ("Application mode", .023),
        ("Curricular units 2nd semester: evaluated", .021),
        ("Curricular units 1st semester: evaluated", .021),
        ("Scholarship holder", .021), ("Unemployment rate", .019),
        ("Previous-qualification grade", .018), ("Debtor", .017),
        ("Gender", .017), ("Course", .016),
        ("Curricular units 1st semester: enrolled", .015),
        ("Curricular units 2nd semester: enrolled", .014),
        ("Inflation rate", .014),
    ],
}

SHAP_GROUPS = [
    ("INELS", "Academic", .334, 38.4), ("INELS", "School context", .248, 28.5),
    ("INELS", "Demographic", .171, 19.7), ("INELS", "Family", .116, 13.4),
    ("UCI", "Second-semester academic", .451, 38.8),
    ("UCI", "First-semester academic", .291, 25.0),
    ("UCI", "Family and financial", .168, 14.5),
    ("UCI", "Application and admission", .112, 9.6),
    ("UCI", "Demographic", .083, 7.1), ("UCI", "Macroeconomic", .057, 4.9),
]

EFFICIENCY = [
    ("Logistic regression", "INELS", "0.01 MB", .38, .031, .002),
    ("Random forest", "INELS", "9.84 MB", 8.42, .386, .033),
    ("MLP", "INELS", "0.22 M parameters", 31.4, .214, .009),
    ("XGBoost", "INELS", "1.92 MB", 5.11, .173, .011),
    ("TabNet", "INELS", "0.58 M parameters", 74.8, .742, .035),
    ("FT-Transformer", "INELS", "1.47 M parameters", 63.5, .613, .026),
    ("CFIN", "INELS", "1.36 M parameters", 79.6, .841, .034),
    ("Logistic regression", "UCI", "0.01 MB", .14, .034, .002),
    ("Random forest", "UCI", "3.21 MB", 2.36, .401, .035),
    ("MLP", "UCI", "0.25 M parameters", 10.8, .225, .010),
    ("XGBoost", "UCI", "1.48 MB", 1.44, .181, .012),
    ("TabNet", "UCI", "0.61 M parameters", 23.7, .759, .037),
    ("FT-Transformer", "UCI", "1.53 M parameters", 20.9, .628, .028),
    ("CFIN", "UCI", "1.64 M parameters", 26.8, .879, .037),
]

