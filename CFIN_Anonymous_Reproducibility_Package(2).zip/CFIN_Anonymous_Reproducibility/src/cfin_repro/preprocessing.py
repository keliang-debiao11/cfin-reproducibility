from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder, StandardScaler


@dataclass
class NeuralArrays:
    numerical: np.ndarray
    categorical: np.ndarray
    categorical_cardinalities: list[int]


class FoldPreprocessor:
    """Fit-on-training-only preprocessing for conventional and neural models."""

    def __init__(
        self,
        numerical_features: Sequence[str],
        categorical_features: Sequence[str],
    ) -> None:
        self.numerical_features = list(numerical_features)
        self.categorical_features = list(categorical_features)
        self.dense_transformer = ColumnTransformer(
            transformers=[
                (
                    "num",
                    Pipeline(
                        [
                            ("impute", SimpleImputer(strategy="median")),
                            ("scale", StandardScaler()),
                        ]
                    ),
                    self.numerical_features,
                ),
                (
                    "cat",
                    Pipeline(
                        [
                            ("impute", SimpleImputer(strategy="most_frequent")),
                            (
                                "onehot",
                                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                            ),
                        ]
                    ),
                    self.categorical_features,
                ),
            ],
            remainder="drop",
        )
        self.numeric_pipeline = Pipeline(
            [("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]
        )
        self.category_pipeline = Pipeline(
            [
                ("impute", SimpleImputer(strategy="most_frequent")),
                (
                    "ordinal",
                    OrdinalEncoder(
                        handle_unknown="use_encoded_value",
                        unknown_value=-1,
                        encoded_missing_value=-1,
                    ),
                ),
            ]
        )
        self._fitted = False

    def fit(self, frame: pd.DataFrame) -> "FoldPreprocessor":
        self.dense_transformer.fit(frame)
        if self.numerical_features:
            self.numeric_pipeline.fit(frame[self.numerical_features])
        if self.categorical_features:
            self.category_pipeline.fit(frame[self.categorical_features])
            ordinal = self.category_pipeline.named_steps["ordinal"]
            self.cardinalities_ = [len(categories) + 1 for categories in ordinal.categories_]
        else:
            self.cardinalities_ = []
        self._fitted = True
        return self

    def transform_dense(self, frame: pd.DataFrame) -> np.ndarray:
        self._check_fitted()
        return np.asarray(self.dense_transformer.transform(frame), dtype=np.float32)

    def transform_neural(self, frame: pd.DataFrame) -> NeuralArrays:
        self._check_fitted()
        if self.numerical_features:
            numerical = self.numeric_pipeline.transform(frame[self.numerical_features]).astype(np.float32)
        else:
            numerical = np.empty((len(frame), 0), dtype=np.float32)
        if self.categorical_features:
            categorical = self.category_pipeline.transform(frame[self.categorical_features]).astype(np.int64)
            categorical += 1  # unknown/missing -1 becomes reserved index 0
        else:
            categorical = np.empty((len(frame), 0), dtype=np.int64)
        return NeuralArrays(numerical, categorical, list(self.cardinalities_))

    def _check_fitted(self) -> None:
        if not self._fitted:
            raise RuntimeError("FoldPreprocessor must be fitted on training data before transformation")


def class_weights(labels: np.ndarray, class_order: Sequence) -> np.ndarray:
    labels = np.asarray(labels)
    n = len(labels)
    classes = list(class_order)
    weights = []
    for cls in classes:
        count = int(np.sum(labels == cls))
        if count == 0:
            raise ValueError(f"Class {cls!r} is absent from the training partition")
        weights.append(n / (len(classes) * count))
    return np.asarray(weights, dtype=np.float32)

