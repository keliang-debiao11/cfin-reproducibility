from __future__ import annotations

from typing import Mapping, Sequence

import torch
from torch import nn

from .tokenizer import FeatureTokenizer, transformer_encoder


class CFIN(nn.Module):
    """Hierarchical feature interaction network used in the manuscript."""

    def __init__(
        self,
        *,
        numerical_names: Sequence[str],
        categorical_names: Sequence[str],
        categorical_cardinalities: Sequence[int],
        groups: Mapping[str, Sequence[str]],
        output_dim: int,
        token_dim: int = 128,
        group_encoder_layers: int = 1,
        group_encoder_heads: int = 4,
        group_ff_dim: int = 256,
        context_encoder_layers: int = 4,
        context_encoder_heads: int = 8,
        context_ff_dim: int = 512,
        dropout: float = 0.10,
        prediction_hidden_dim: int = 64,
        use_context_encoder: bool = True,
        flat_encoder: bool = False,
    ) -> None:
        super().__init__()
        self.tokenizer = FeatureTokenizer(
            numerical_names,
            categorical_names,
            categorical_cardinalities,
            token_dim,
        )
        known = set(self.tokenizer.feature_names)
        self.groups = {name: list(features) for name, features in groups.items()}
        used = [feature for features in self.groups.values() for feature in features]
        if set(used) != known or len(used) != len(known):
            missing = sorted(known - set(used))
            duplicate_or_unknown = sorted(set(used) - known)
            raise ValueError(
                "Groups must form a complete, non-overlapping feature partition; "
                f"missing={missing}, unknown={duplicate_or_unknown}, entries={len(used)}, unique={len(set(used))}"
            )
        self.group_names = list(self.groups)
        self.use_context_encoder = bool(use_context_encoder)
        self.flat_encoder_enabled = bool(flat_encoder)
        self.group_tokens = nn.Parameter(torch.empty(len(self.groups), 1, token_dim))
        self.global_token = nn.Parameter(torch.empty(1, 1, token_dim))
        nn.init.normal_(self.group_tokens, std=0.02)
        nn.init.normal_(self.global_token, std=0.02)

        self.group_encoders = nn.ModuleDict(
            {
                name: transformer_encoder(
                    token_dim=token_dim,
                    heads=group_encoder_heads,
                    ff_dim=group_ff_dim,
                    layers=group_encoder_layers,
                    dropout=dropout,
                )
                for name in self.group_names
            }
        )
        self.context_encoder = transformer_encoder(
            token_dim=token_dim,
            heads=context_encoder_heads,
            ff_dim=context_ff_dim,
            layers=context_encoder_layers,
            dropout=dropout,
        )
        self.flat_encoder = transformer_encoder(
            token_dim=token_dim,
            heads=context_encoder_heads,
            ff_dim=context_ff_dim,
            layers=context_encoder_layers,
            dropout=dropout,
        )
        self.no_context_projection = nn.Linear(len(self.groups) * token_dim, token_dim)
        self.head = nn.Sequential(
            nn.LayerNorm(token_dim),
            nn.Linear(token_dim, prediction_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(prediction_hidden_dim, output_dim),
        )

    def forward(self, numerical: torch.Tensor, categorical: torch.Tensor) -> torch.Tensor:
        token_map = self.tokenizer(numerical, categorical)
        batch = numerical.shape[0]
        if self.flat_encoder_enabled:
            global_token = self.global_token.expand(batch, -1, -1)
            features = torch.stack([token_map[name] for name in self.tokenizer.feature_names], dim=1)
            encoded = self.flat_encoder(torch.cat([global_token, features], dim=1))
            return self.head(encoded[:, 0])

        representations = []
        for index, group_name in enumerate(self.group_names):
            group_token = self.group_tokens[index : index + 1].expand(batch, -1, -1)
            feature_tokens = torch.stack(
                [token_map[name] for name in self.groups[group_name]], dim=1
            )
            encoded = self.group_encoders[group_name](
                torch.cat([group_token, feature_tokens], dim=1)
            )
            representations.append(encoded[:, 0])
        group_matrix = torch.stack(representations, dim=1)
        if self.use_context_encoder:
            global_token = self.global_token.expand(batch, -1, -1)
            contextual = self.context_encoder(torch.cat([global_token, group_matrix], dim=1))
            representation = contextual[:, 0]
        else:
            representation = self.no_context_projection(group_matrix.flatten(start_dim=1))
        return self.head(representation)

