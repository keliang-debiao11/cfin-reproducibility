from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class WeightedFocalLoss(nn.Module):
    def __init__(self, class_weights: torch.Tensor, gamma: float = 2.0) -> None:
        super().__init__()
        self.register_buffer("class_weights", class_weights.float())
        self.gamma = float(gamma)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        if logits.ndim != 2:
            raise ValueError("Logits must have shape [batch, outputs]")
        targets = targets.long()
        if logits.shape[1] == 1:
            positive_logits = logits[:, 0]
            targets_float = targets.float()
            probabilities = torch.sigmoid(positive_logits)
            p_t = torch.where(targets.bool(), probabilities, 1.0 - probabilities)
            alpha_t = self.class_weights[targets]
            bce = F.binary_cross_entropy_with_logits(
                positive_logits, targets_float, reduction="none"
            )
            return (alpha_t * (1.0 - p_t).pow(self.gamma) * bce).mean()
        log_probabilities = F.log_softmax(logits, dim=1)
        probabilities = log_probabilities.exp()
        index = torch.arange(len(targets), device=targets.device)
        p_t = probabilities[index, targets]
        log_p_t = log_probabilities[index, targets]
        alpha_t = self.class_weights[targets]
        return (-alpha_t * (1.0 - p_t).pow(self.gamma) * log_p_t).mean()


class CrossEntropyByShape(nn.Module):
    def __init__(self, class_weights: torch.Tensor | None) -> None:
        super().__init__()
        if class_weights is None:
            self.class_weights = None
        else:
            self.register_buffer("class_weights", class_weights.float())

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        targets = targets.long()
        if logits.shape[1] == 1:
            raw = F.binary_cross_entropy_with_logits(
                logits[:, 0], targets.float(), reduction="none"
            )
            if self.class_weights is not None:
                raw = raw * self.class_weights[targets]
            return raw.mean()
        return F.cross_entropy(logits, targets, weight=self.class_weights)


def make_loss(name: str, class_weights: torch.Tensor, gamma: float = 2.0) -> nn.Module:
    if name == "weighted_focal":
        return WeightedFocalLoss(class_weights, gamma)
    if name == "weighted_cross_entropy":
        return CrossEntropyByShape(class_weights)
    if name == "cross_entropy":
        return CrossEntropyByShape(None)
    raise ValueError(f"Unknown loss: {name}")

