from __future__ import annotations

from typing import Sequence

import torch
from torch import nn

from .tokenizer import FeatureTokenizer, transformer_encoder


class FTTransformer(nn.Module):
    def __init__(
        self,
        *,
        numerical_names: Sequence[str],
        categorical_names: Sequence[str],
        categorical_cardinalities: Sequence[int],
        output_dim: int,
        token_dim: int = 128,
        layers: int = 4,
        heads: int = 8,
        ff_multiplier: int = 4,
        dropout: float = 0.10,
    ) -> None:
        super().__init__()
        self.tokenizer = FeatureTokenizer(
            numerical_names,
            categorical_names,
            categorical_cardinalities,
            token_dim,
        )
        self.cls_token = nn.Parameter(torch.empty(1, 1, token_dim))
        nn.init.normal_(self.cls_token, std=0.02)
        self.encoder = transformer_encoder(
            token_dim=token_dim,
            heads=heads,
            ff_dim=token_dim * ff_multiplier,
            layers=layers,
            dropout=dropout,
        )
        self.head = nn.Sequential(nn.LayerNorm(token_dim), nn.Linear(token_dim, output_dim))

    def forward(self, numerical: torch.Tensor, categorical: torch.Tensor) -> torch.Tensor:
        token_map = self.tokenizer(numerical, categorical)
        tokens = torch.stack([token_map[name] for name in self.tokenizer.feature_names], dim=1)
        cls = self.cls_token.expand(tokens.shape[0], -1, -1)
        encoded = self.encoder(torch.cat([cls, tokens], dim=1))
        return self.head(encoded[:, 0])

