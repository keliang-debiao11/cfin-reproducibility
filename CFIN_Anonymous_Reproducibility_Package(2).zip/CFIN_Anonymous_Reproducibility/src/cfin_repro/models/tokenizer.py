from __future__ import annotations

from collections import OrderedDict
from typing import Sequence

import torch
from torch import nn


class FeatureTokenizer(nn.Module):
    """Feature-specific numerical projections and categorical embeddings."""

    def __init__(
        self,
        numerical_names: Sequence[str],
        categorical_names: Sequence[str],
        categorical_cardinalities: Sequence[int],
        token_dim: int,
    ) -> None:
        super().__init__()
        self.numerical_names = list(numerical_names)
        self.categorical_names = list(categorical_names)
        if len(self.categorical_names) != len(categorical_cardinalities):
            raise ValueError("One categorical cardinality is required per categorical feature")
        self.token_dim = int(token_dim)
        self.numerical_weight = nn.Parameter(
            torch.empty(len(self.numerical_names), self.token_dim)
        )
        self.numerical_bias = nn.Parameter(
            torch.zeros(len(self.numerical_names), self.token_dim)
        )
        self.categorical_embeddings = nn.ModuleList(
            [nn.Embedding(int(cardinality), self.token_dim) for cardinality in categorical_cardinalities]
        )
        self.feature_names = self.numerical_names + self.categorical_names
        self.identity = nn.Parameter(torch.empty(len(self.feature_names), self.token_dim))
        nn.init.xavier_uniform_(self.numerical_weight)
        nn.init.normal_(self.identity, std=0.02)
        for embedding in self.categorical_embeddings:
            nn.init.normal_(embedding.weight, std=0.02)

    def forward(
        self,
        numerical: torch.Tensor,
        categorical: torch.Tensor,
    ) -> OrderedDict[str, torch.Tensor]:
        tokens: OrderedDict[str, torch.Tensor] = OrderedDict()
        if numerical.shape[1] != len(self.numerical_names):
            raise ValueError("Numerical tensor width does not match the configured features")
        if categorical.shape[1] != len(self.categorical_names):
            raise ValueError("Categorical tensor width does not match the configured features")
        for index, name in enumerate(self.numerical_names):
            token = (
                numerical[:, index : index + 1] * self.numerical_weight[index]
                + self.numerical_bias[index]
                + self.identity[index]
            )
            tokens[name] = token
        offset = len(self.numerical_names)
        for index, name in enumerate(self.categorical_names):
            values = categorical[:, index].long()
            token = self.categorical_embeddings[index](values) + self.identity[offset + index]
            tokens[name] = token
        return tokens


def transformer_encoder(
    *,
    token_dim: int,
    heads: int,
    ff_dim: int,
    layers: int,
    dropout: float,
) -> nn.TransformerEncoder:
    if token_dim % heads != 0:
        raise ValueError(f"token_dim={token_dim} must be divisible by heads={heads}")
    layer = nn.TransformerEncoderLayer(
        d_model=token_dim,
        nhead=heads,
        dim_feedforward=ff_dim,
        dropout=dropout,
        activation="gelu",
        batch_first=True,
        norm_first=True,
    )
    return nn.TransformerEncoder(layer, num_layers=layers, norm=nn.LayerNorm(token_dim))

