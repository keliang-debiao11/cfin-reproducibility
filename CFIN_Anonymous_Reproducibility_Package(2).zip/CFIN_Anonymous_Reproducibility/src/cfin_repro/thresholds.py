from __future__ import annotations

import numpy as np
from sklearn.metrics import f1_score


def threshold_grid(minimum: float = 0.05, maximum: float = 0.95, step: float = 0.01) -> np.ndarray:
    count = int(round((maximum - minimum) / step)) + 1
    return np.round(np.linspace(minimum, maximum, count), 10)


def select_macro_f1_threshold(
    y_true: np.ndarray,
    positive_probabilities: np.ndarray,
    *,
    minimum: float = 0.05,
    maximum: float = 0.95,
    step: float = 0.01,
) -> tuple[float, float]:
    y_true = np.asarray(y_true, dtype=int)
    probs = np.asarray(positive_probabilities, dtype=float)
    candidates = threshold_grid(minimum, maximum, step)
    scores = np.asarray(
        [f1_score(y_true, probs >= threshold, average="macro") for threshold in candidates]
    )
    best = scores.max()
    tied = candidates[np.isclose(scores, best, atol=1e-12)]
    chosen = tied[np.argmin(np.abs(tied - 0.5))]
    return float(chosen), float(best)


def assert_oof_complete(oof_probabilities: np.ndarray) -> None:
    probabilities = np.asarray(oof_probabilities, dtype=float)
    if probabilities.ndim != 1:
        raise ValueError("Binary OOF probabilities must be one-dimensional")
    if np.isnan(probabilities).any():
        missing = int(np.isnan(probabilities).sum())
        raise ValueError(f"OOF predictions are incomplete: {missing} records have no prediction")
    if np.any((probabilities < 0) | (probabilities > 1)):
        raise ValueError("OOF probabilities must lie in [0, 1]")

