from __future__ import annotations

import numpy as np


def holm_adjust(p_values: list[float] | np.ndarray) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    m = len(values)
    for rank, index in enumerate(order):
        candidate = (m - rank) * values[index]
        running = max(running, candidate)
        adjusted[index] = min(running, 1.0)
    return adjusted


def paired_stratified_bootstrap_difference(
    y_true: np.ndarray,
    score_a: np.ndarray,
    score_b: np.ndarray,
    metric,
    *,
    metric_b=None,
    samples: int = 10_000,
    seed: int = 2025,
) -> tuple[float, float, float, float]:
    y_true = np.asarray(y_true)
    score_a = np.asarray(score_a)
    score_b = np.asarray(score_b)
    rng = np.random.default_rng(seed)
    class_indices = [np.flatnonzero(y_true == cls) for cls in np.unique(y_true)]
    metric_b = metric if metric_b is None else metric_b
    observed = float(metric(y_true, score_a) - metric_b(y_true, score_b))
    differences = np.empty(samples, dtype=float)
    for i in range(samples):
        sampled = np.concatenate(
            [rng.choice(indices, size=len(indices), replace=True) for indices in class_indices]
        )
        differences[i] = metric(y_true[sampled], score_a[sampled]) - metric_b(
            y_true[sampled], score_b[sampled]
        )
    low, high = np.quantile(differences, [0.025, 0.975])
    p_two_sided = 2.0 * min(np.mean(differences <= 0), np.mean(differences >= 0))
    return observed, float(low), float(high), float(min(p_two_sided, 1.0))

