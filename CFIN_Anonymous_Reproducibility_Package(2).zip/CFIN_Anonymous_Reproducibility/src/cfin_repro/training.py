from __future__ import annotations

import copy
import time
from dataclasses import dataclass
from typing import Callable

import numpy as np
import torch
from sklearn.metrics import f1_score
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


@dataclass
class FitResult:
    best_epoch: int
    best_validation_macro_f1: float
    epochs_run: int
    training_seconds: float
    history: list[dict[str, float]]


def _loader(inputs: tuple[np.ndarray, ...], labels: np.ndarray, batch_size: int, shuffle: bool) -> DataLoader:
    tensors = [torch.from_numpy(np.asarray(array)) for array in inputs]
    tensors.append(torch.from_numpy(np.asarray(labels, dtype=np.int64)))
    return DataLoader(
        TensorDataset(*tensors),
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=0,
        drop_last=False,
    )


def probabilities_from_logits(logits: torch.Tensor) -> torch.Tensor:
    if logits.shape[1] == 1:
        return torch.sigmoid(logits[:, 0])
    return torch.softmax(logits, dim=1)


def _forward(model: nn.Module, batch_inputs: tuple[torch.Tensor, ...]) -> torch.Tensor:
    return model(*batch_inputs)


@torch.no_grad()
def predict_neural(
    model: nn.Module,
    inputs: tuple[np.ndarray, ...],
    *,
    batch_size: int,
    device: torch.device,
) -> np.ndarray:
    model.eval()
    dummy = np.zeros(len(inputs[0]), dtype=np.int64)
    loader = _loader(inputs, dummy, batch_size, False)
    predictions = []
    for batch in loader:
        batch_inputs = tuple(t.to(device) for t in batch[:-1])
        predictions.append(probabilities_from_logits(_forward(model, batch_inputs)).cpu().numpy())
    return np.concatenate(predictions, axis=0)


def fit_neural(
    model: nn.Module,
    train_inputs: tuple[np.ndarray, ...],
    train_labels: np.ndarray,
    validation_inputs: tuple[np.ndarray, ...],
    validation_labels: np.ndarray,
    *,
    criterion: nn.Module,
    learning_rate: float,
    weight_decay: float,
    batch_size: int,
    max_epochs: int,
    patience: int,
    min_delta: float,
    gradient_clip_norm: float,
    device: torch.device,
    epoch_callback: Callable[[dict[str, float]], None] | None = None,
) -> FitResult:
    model.to(device)
    criterion.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=weight_decay
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_epochs)
    train_loader = _loader(train_inputs, train_labels, batch_size, True)
    best_score = -np.inf
    best_epoch = 0
    best_state = copy.deepcopy(model.state_dict())
    wait = 0
    history: list[dict[str, float]] = []
    start = time.perf_counter()

    for epoch in range(1, max_epochs + 1):
        model.train()
        losses = []
        for batch in train_loader:
            batch_inputs = tuple(t.to(device) for t in batch[:-1])
            labels = batch[-1].to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = _forward(model, batch_inputs)
            loss = criterion(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        scheduler.step()

        probabilities = predict_neural(
            model, validation_inputs, batch_size=batch_size, device=device
        )
        if probabilities.ndim == 1:
            predicted = (probabilities >= 0.5).astype(int)
        else:
            predicted = probabilities.argmax(axis=1)
        validation_f1 = float(f1_score(validation_labels, predicted, average="macro"))
        record = {
            "epoch": float(epoch),
            "train_loss": float(np.mean(losses)),
            "validation_macro_f1": validation_f1,
            "learning_rate": float(optimizer.param_groups[0]["lr"]),
        }
        history.append(record)
        if epoch_callback is not None:
            epoch_callback(record)
        if validation_f1 > best_score + min_delta:
            best_score = validation_f1
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
        if wait >= patience:
            break

    model.load_state_dict(best_state)
    return FitResult(
        best_epoch=best_epoch,
        best_validation_macro_f1=float(best_score),
        epochs_run=len(history),
        training_seconds=float(time.perf_counter() - start),
        history=history,
    )

