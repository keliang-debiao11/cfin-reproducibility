from __future__ import annotations

import numpy as np
from scipy.stats import norm


def _midrank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_values = values[order]
    ranks = np.empty(len(values), dtype=float)
    i = 0
    while i < len(values):
        j = i
        while j < len(values) and sorted_values[j] == sorted_values[i]:
            j += 1
        ranks[i:j] = 0.5 * (i + j - 1) + 1
        i = j
    output = np.empty(len(values), dtype=float)
    output[order] = ranks
    return output


def _fast_delong(predictions: np.ndarray, positive_count: int):
    m = positive_count
    n = predictions.shape[1] - m
    positive = predictions[:, :m]
    negative = predictions[:, m:]
    tx = np.vstack([_midrank(row) for row in positive])
    ty = np.vstack([_midrank(row) for row in negative])
    tz = np.vstack([_midrank(row) for row in predictions])
    aucs = (tz[:, :m].sum(axis=1) / m - (m + 1) / 2.0) / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    covariance = np.cov(v01) / m + np.cov(v10) / n
    return aucs, np.atleast_2d(covariance)


def paired_delong_test(
    y_true: np.ndarray, score_a: np.ndarray, score_b: np.ndarray
) -> tuple[float, float, float]:
    y_true = np.asarray(y_true, dtype=int)
    if set(np.unique(y_true)) != {0, 1}:
        raise ValueError("DeLong test requires binary labels encoded as 0/1")
    order = np.argsort(-y_true)
    positive_count = int(y_true.sum())
    predictions = np.vstack([score_a, score_b])[:, order]
    aucs, covariance = _fast_delong(predictions, positive_count)
    contrast = np.array([[1.0, -1.0]])
    variance = float(contrast @ covariance @ contrast.T)
    difference = float(aucs[0] - aucs[1])
    if variance <= 0:
        return difference, 0.0, 1.0
    standard_error = np.sqrt(variance)
    z = difference / standard_error
    p_value = float(2.0 * norm.sf(abs(z)))
    return difference, float(standard_error), p_value

