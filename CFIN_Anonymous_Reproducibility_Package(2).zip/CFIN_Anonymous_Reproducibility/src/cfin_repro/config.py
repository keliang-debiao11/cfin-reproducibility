from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def load_yaml(path: str | Path) -> dict[str, Any]:
    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = PROJECT_ROOT / candidate
    with candidate.open("r", encoding="utf-8") as stream:
        value = yaml.safe_load(stream)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a mapping in {candidate}")
    return value


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def dataset_config(name: str) -> dict[str, Any]:
    if name not in {"inels", "uci"}:
        raise ValueError(f"Unsupported dataset: {name}")
    return load_yaml(f"configs/datasets/{name}.yaml")


def resolved_experiment_config(path: str | Path) -> dict[str, Any]:
    config = load_yaml(path)
    config["cfin"] = load_yaml("configs/models/cfin.yaml")
    config["baselines"] = load_yaml("configs/models/baselines.yaml")
    config["analyses"] = load_yaml("configs/analyses.yaml")
    config["dataset_specs"] = {
        name: dataset_config(name) for name in config["experiment"]["datasets"]
    }
    return config

