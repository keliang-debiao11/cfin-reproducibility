from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def evaluate_classification(
    y_true: np.ndarray,
    probabilities: np.ndarray,
    *,
    threshold: float | None = None,
    labels: list[Any] | None = None,
) -> dict[str, float]:
    y_true = np.asarray(y_true)
    probabilities = np.asarray(probabilities)
    if probabilities.ndim == 1 or probabilities.shape[1] in {1, 2}:
        positive = probabilities.ravel() if probabilities.ndim == 1 else probabilities[:, -1]
        cutoff = 0.5 if threshold is None else float(threshold)
        y_pred = (positive >= cutoff).astype(int)
        auc = roc_auc_score(y_true, positive)
    else:
        y_pred = probabilities.argmax(axis=1)
        auc = roc_auc_score(
            y_true,
            probabilities,
            labels=labels,
            multi_class="ovr",
            average="macro",
        )
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_precision": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_auc": float(auc),
    }


def mean_sd(values: list[float] | np.ndarray) -> tuple[float, float]:
    array = np.asarray(values, dtype=float)
    return float(array.mean()), float(array.std(ddof=1))


def mean_sd_ci(values: list[float] | np.ndarray, confidence: float = 0.95) -> dict[str, float]:
    from scipy.stats import t

    array = np.asarray(values, dtype=float)
    mean, sd = mean_sd(array)
    alpha = 1.0 - confidence
    half = float(t.ppf(1.0 - alpha / 2.0, len(array) - 1) * sd / np.sqrt(len(array)))
    return {"mean": mean, "sd": sd, "ci_low": mean - half, "ci_high": mean + half}

