from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder

from .adapters import fit_predict
from .config import PROJECT_ROOT, resolved_experiment_config
from .data import fixed_split_indices, load_dataset
from .metrics import evaluate_classification
from .provenance import runtime_provenance, write_json
from .thresholds import assert_oof_complete, select_macro_f1_threshold


def _default_parameters(model_name: str, config: dict[str, Any]) -> dict[str, Any]:
    if model_name == "cfin":
        return {k: v for k, v in config["cfin"].items() if k not in {"search_space", "model"}}
    defaults = {
        "logistic_regression": {"C": 1.0, "penalty": "l2", "solver": "liblinear"},
        "random_forest": {"n_estimators": 500, "max_depth": None, "min_samples_split": 2, "max_features": "sqrt"},
        "xgboost": {"n_estimators": 500, "max_depth": 6, "learning_rate": 0.05, "subsample": 0.9, "colsample_bytree": 0.9, "min_child_weight": 1},
        "mlp": {"hidden_dims": [256, 128, 64], "dropout": 0.20, "learning_rate": 1e-4, "weight_decay": 1e-4, "batch_size": 256, "loss": "weighted_focal", "focal_gamma": 2.0},
        "ft_transformer": {"token_dim": 128, "layers": 4, "heads": 8, "ff_multiplier": 4, "dropout": 0.10, "learning_rate": 1e-4, "weight_decay": 1e-4, "batch_size": 256, "loss": "weighted_focal", "focal_gamma": 2.0},
    }
    if model_name not in defaults:
        raise ValueError(f"No default parameters registered for {model_name}")
    return defaults[model_name]


def encode_target(dataset_name: str, target) -> tuple[np.ndarray, list[str]]:
    if dataset_name == "inels":
        order = ["Retained", "Dropout"]
    else:
        order = ["Dropout", "Enrolled", "Graduate"]
    mapping = {label: index for index, label in enumerate(order)}
    encoded = target.map(mapping)
    if encoded.isna().any():
        raise ValueError("Target contains labels outside the configured class order")
    return encoded.to_numpy(dtype=np.int64), order


def oof_threshold(
    model_name: str,
    parameters: dict[str, Any],
    dataset,
    train_indices: np.ndarray,
    encoded_target: np.ndarray,
    seed: int,
) -> tuple[float, float]:
    splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    train_target = encoded_target[train_indices]
    oof = np.full(len(train_indices), np.nan, dtype=float)
    for fold_train_local, fold_validation_local in splitter.split(train_indices, train_target):
        fold_train = train_indices[fold_train_local]
        fold_validation = train_indices[fold_validation_local]
        prediction = fit_predict(
            model_name,
            parameters,
            dataset,
            fold_train,
            fold_validation,
            encoded_target,
            seed=seed,
        )
        oof[fold_validation_local] = np.asarray(prediction.probabilities).reshape(-1)
    assert_oof_complete(oof)
    return select_macro_f1_threshold(train_target, oof)


def run_single(
    config_path: str | Path,
    dataset_name: str,
    model_name: str,
    seed: int,
    *,
    parameters: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = resolved_experiment_config(config_path)
    dataset = load_dataset(dataset_name)
    encoded_target, class_order = encode_target(dataset_name, dataset.target)
    train_indices, test_indices = fixed_split_indices(
        dataset.target,
        seed=config["experiment"]["split_seed"],
        test_size=config["experiment"]["test_size"],
    )
    params = _default_parameters(model_name, config) if parameters is None else parameters
    threshold = None
    threshold_oof_f1 = None
    if dataset_name == "inels":
        threshold, threshold_oof_f1 = oof_threshold(
            model_name, params, dataset, train_indices, encoded_target, seed
        )
    prediction = fit_predict(
        model_name,
        params,
        dataset,
        train_indices,
        test_indices,
        encoded_target,
        seed=seed,
    )
    metrics = evaluate_classification(
        encoded_target[test_indices],
        prediction.probabilities,
        threshold=threshold,
        labels=list(range(len(class_order))),
    )
    result = {
        "provenance": "REAL_EXECUTION",
        "dataset": dataset_name,
        "model": model_name,
        "seed": seed,
        "threshold": threshold,
        "threshold_oof_macro_f1": threshold_oof_f1,
        "metrics": metrics,
        "fit": prediction.metadata,
        "parameters": params,
    }
    output = PROJECT_ROOT / "results/real" / dataset_name / model_name / f"seed_{seed}.json"
    write_json(output, result)
    np.savez_compressed(
        output.with_suffix(".predictions.npz"),
        test_indices=test_indices,
        y_true=encoded_target[test_indices],
        probabilities=np.asarray(prediction.probabilities),
        threshold=np.asarray([np.nan if threshold is None else threshold]),
    )
    return result


def dry_run_plan(config_path: str | Path) -> dict[str, Any]:
    config = resolved_experiment_config(config_path)
    experiment = config["experiment"]
    plan = {
        "datasets": experiment["datasets"],
        "models": experiment["models"],
        "seeds": experiment["final_seeds"],
        "tuning_trials_per_model_dataset": experiment["tuning_trials"],
        "planned_final_runs": len(experiment["datasets"])
        * len(experiment["models"])
        * len(experiment["final_seeds"]),
        "threshold_protocol": config["threshold_selection"],
        "early_stopping": config["early_stopping"],
        "provenance": runtime_provenance(PROJECT_ROOT, {"config_path": str(config_path)}),
    }
    return plan


def append_jsonl(path: Path, record: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(record, sort_keys=True) + "\n")

