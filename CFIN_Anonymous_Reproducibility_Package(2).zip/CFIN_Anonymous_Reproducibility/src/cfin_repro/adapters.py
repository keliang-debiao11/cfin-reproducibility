from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

from .data import PreparedDataset
from .preprocessing import FoldPreprocessor, class_weights
from .seed import set_global_seed


@dataclass
class PredictionResult:
    probabilities: np.ndarray
    metadata: dict[str, Any]
    fitted_model: Any
    preprocessor: FoldPreprocessor


def _device():
    import torch

    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _internal_validation_indices(y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    indices = np.arange(len(y))
    fit, validation = train_test_split(
        indices,
        test_size=0.10,
        random_state=2025,
        stratify=y,
    )
    return np.asarray(fit), np.asarray(validation)


def _output_dim(y: np.ndarray) -> int:
    return 1 if len(np.unique(y)) == 2 else len(np.unique(y))


def _fit_sklearn(
    model_name: str,
    parameters: dict[str, Any],
    train_dense: np.ndarray,
    y_train: np.ndarray,
    evaluation_dense: np.ndarray,
    seed: int,
) -> tuple[Any, np.ndarray, dict[str, Any]]:
    if model_name == "logistic_regression":
        model = LogisticRegression(
            C=float(parameters.get("C", 1.0)),
            penalty=parameters.get("penalty", "l2"),
            solver=parameters.get("solver", "liblinear"),
            class_weight="balanced",
            max_iter=5000,
            random_state=seed,
            n_jobs=1,
        )
    elif model_name == "random_forest":
        max_features = parameters.get("max_features", "sqrt")
        if max_features == "half":
            max_features = 0.5
        elif max_features == "all":
            max_features = 1.0
        model = RandomForestClassifier(
            n_estimators=int(parameters.get("n_estimators", 500)),
            max_depth=parameters.get("max_depth"),
            min_samples_split=int(parameters.get("min_samples_split", 2)),
            max_features=max_features,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
    elif model_name == "xgboost":
        from xgboost import XGBClassifier

        classes = len(np.unique(y_train))
        model = XGBClassifier(
            n_estimators=int(parameters.get("n_estimators", 500)),
            max_depth=int(parameters.get("max_depth", 6)),
            learning_rate=float(parameters.get("learning_rate", 0.05)),
            subsample=float(parameters.get("subsample", 0.9)),
            colsample_bytree=float(parameters.get("colsample_bytree", 0.9)),
            min_child_weight=float(parameters.get("min_child_weight", 1.0)),
            objective="binary:logistic" if classes == 2 else "multi:softprob",
            num_class=None if classes == 2 else classes,
            eval_metric="logloss" if classes == 2 else "mlogloss",
            random_state=seed,
            n_jobs=-1,
        )
    else:
        raise ValueError(model_name)
    model.fit(train_dense, y_train)
    probabilities = model.predict_proba(evaluation_dense)
    if probabilities.shape[1] == 2:
        probabilities = probabilities[:, 1]
    return model, probabilities, {}


def _fit_neural(
    model_name: str,
    parameters: dict[str, Any],
    dataset: PreparedDataset,
    preprocessor: FoldPreprocessor,
    x_train: pd.DataFrame,
    y_train: np.ndarray,
    x_evaluation: pd.DataFrame,
    seed: int,
) -> tuple[Any, np.ndarray, dict[str, Any]]:
    import torch

    from .models import CFIN, FTTransformer, MLP
    from .models.losses import make_loss
    from .training import fit_neural, predict_neural

    fit_indices, validation_indices = _internal_validation_indices(y_train)
    output_dim = _output_dim(y_train)
    dense_train = preprocessor.transform_dense(x_train)
    dense_eval = preprocessor.transform_dense(x_evaluation)
    neural_train = preprocessor.transform_neural(x_train)
    neural_eval = preprocessor.transform_neural(x_evaluation)
    if model_name == "mlp":
        model = MLP(
            input_dim=dense_train.shape[1],
            output_dim=output_dim,
            hidden_dims=parameters.get("hidden_dims", [256, 128, 64]),
            dropout=float(parameters.get("dropout", 0.20)),
        )
        train_inputs = (dense_train[fit_indices],)
        validation_inputs = (dense_train[validation_indices],)
        evaluation_inputs = (dense_eval,)
    elif model_name == "ft_transformer":
        model = FTTransformer(
            numerical_names=dataset.numeric_features,
            categorical_names=dataset.categorical_features,
            categorical_cardinalities=neural_train.categorical_cardinalities,
            output_dim=output_dim,
            token_dim=int(parameters.get("token_dim", 128)),
            layers=int(parameters.get("layers", 4)),
            heads=int(parameters.get("heads", 8)),
            ff_multiplier=int(parameters.get("ff_multiplier", 4)),
            dropout=float(parameters.get("dropout", 0.10)),
        )
        train_inputs = (
            neural_train.numerical[fit_indices],
            neural_train.categorical[fit_indices],
        )
        validation_inputs = (
            neural_train.numerical[validation_indices],
            neural_train.categorical[validation_indices],
        )
        evaluation_inputs = (neural_eval.numerical, neural_eval.categorical)
    elif model_name == "cfin":
        model = CFIN(
            numerical_names=dataset.numeric_features,
            categorical_names=dataset.categorical_features,
            categorical_cardinalities=neural_train.categorical_cardinalities,
            groups=dataset.groups,
            output_dim=output_dim,
            token_dim=int(parameters.get("token_dim", 128)),
            group_encoder_layers=int(parameters.get("group_encoder_layers", 1)),
            group_encoder_heads=int(parameters.get("group_encoder_heads", 4)),
            group_ff_dim=int(parameters.get("group_ff_dim", 256)),
            context_encoder_layers=int(parameters.get("context_encoder_layers", 4)),
            context_encoder_heads=int(parameters.get("context_encoder_heads", 8)),
            context_ff_dim=int(parameters.get("context_ff_dim", 512)),
            dropout=float(parameters.get("dropout", 0.10)),
            prediction_hidden_dim=int(parameters.get("prediction_hidden_dim", 64)),
            use_context_encoder=bool(parameters.get("use_context_encoder", True)),
            flat_encoder=bool(parameters.get("flat_encoder", False)),
        )
        train_inputs = (
            neural_train.numerical[fit_indices],
            neural_train.categorical[fit_indices],
        )
        validation_inputs = (
            neural_train.numerical[validation_indices],
            neural_train.categorical[validation_indices],
        )
        evaluation_inputs = (neural_eval.numerical, neural_eval.categorical)
    else:
        raise ValueError(model_name)

    weights = class_weights(y_train[fit_indices], list(range(2 if output_dim == 1 else output_dim)))
    criterion = make_loss(
        parameters.get("loss", "weighted_focal"),
        torch.tensor(weights),
        float(parameters.get("focal_gamma", 2.0)),
    )
    fit_result = fit_neural(
        model,
        train_inputs,
        y_train[fit_indices],
        validation_inputs,
        y_train[validation_indices],
        criterion=criterion,
        learning_rate=float(parameters.get("learning_rate", 1e-4)),
        weight_decay=float(parameters.get("weight_decay", 1e-4)),
        batch_size=int(parameters.get("batch_size", 256)),
        max_epochs=int(parameters.get("max_epochs", 200)),
        patience=int(parameters.get("patience", 20)),
        min_delta=float(parameters.get("min_delta", 1e-4)),
        gradient_clip_norm=float(parameters.get("gradient_clip_norm", 1.0)),
        device=_device(),
    )
    probabilities = predict_neural(
        model,
        evaluation_inputs,
        batch_size=int(parameters.get("batch_size", 256)),
        device=_device(),
    )
    return model, probabilities, {
        "best_epoch": fit_result.best_epoch,
        "best_validation_macro_f1": fit_result.best_validation_macro_f1,
        "epochs_run": fit_result.epochs_run,
        "training_seconds": fit_result.training_seconds,
        "history": fit_result.history,
    }


def fit_predict(
    model_name: str,
    parameters: dict[str, Any],
    dataset: PreparedDataset,
    train_indices: np.ndarray,
    evaluation_indices: np.ndarray,
    encoded_target: np.ndarray,
    *,
    seed: int,
) -> PredictionResult:
    set_global_seed(seed)
    x_train = dataset.frame.iloc[train_indices]
    x_evaluation = dataset.frame.iloc[evaluation_indices]
    y_train = encoded_target[train_indices]
    preprocessor = FoldPreprocessor(dataset.numeric_features, dataset.categorical_features)
    preprocessor.fit(x_train)
    if model_name in {"logistic_regression", "random_forest", "xgboost"}:
        model, probabilities, metadata = _fit_sklearn(
            model_name,
            parameters,
            preprocessor.transform_dense(x_train),
            y_train,
            preprocessor.transform_dense(x_evaluation),
            seed,
        )
    elif model_name in {"mlp", "ft_transformer", "cfin"}:
        model, probabilities, metadata = _fit_neural(
            model_name,
            parameters,
            dataset,
            preprocessor,
            x_train,
            y_train,
            x_evaluation,
            seed,
        )
    elif model_name == "tabnet":
        import torch
        from pytorch_tabnet.metrics import Metric
        from pytorch_tabnet.tab_model import TabNetClassifier
        from sklearn.metrics import f1_score
        from .models.losses import WeightedFocalLoss

        dense_train = preprocessor.transform_dense(x_train)
        dense_eval = preprocessor.transform_dense(x_evaluation)
        fit_indices, validation_indices = _internal_validation_indices(y_train)
        weights = class_weights(y_train[fit_indices], list(range(len(np.unique(y_train)))))

        class MacroF1Metric(Metric):
            def __init__(self):
                self._name = "macro_f1"
                self._maximize = True

            def __call__(self, y_true, y_score):
                return f1_score(y_true, np.asarray(y_score).argmax(axis=1), average="macro")

        model = TabNetClassifier(
            n_d=int(parameters.get("n_d", 32)),
            n_a=int(parameters.get("n_a", 32)),
            n_steps=int(parameters.get("n_steps", 4)),
            gamma=float(parameters.get("gamma", 1.5)),
            lambda_sparse=float(parameters.get("lambda_sparse", 1e-4)),
            optimizer_fn=torch.optim.AdamW,
            optimizer_params={
                "lr": float(parameters.get("learning_rate", 1e-4)),
                "weight_decay": float(parameters.get("weight_decay", 1e-4)),
            },
            seed=seed,
            verbose=0,
            device_name="cuda" if torch.cuda.is_available() else "cpu",
        )
        model.fit(
            dense_train[fit_indices],
            y_train[fit_indices],
            eval_set=[(dense_train[validation_indices], y_train[validation_indices])],
            eval_name=["validation"],
            eval_metric=[MacroF1Metric],
            max_epochs=int(parameters.get("max_epochs", 200)),
            patience=int(parameters.get("patience", 20)),
            batch_size=int(parameters.get("batch_size", 256)),
            virtual_batch_size=min(128, int(parameters.get("batch_size", 256))),
            loss_fn=WeightedFocalLoss(
                torch.tensor(weights), float(parameters.get("focal_gamma", 2.0))
            ),
            drop_last=False,
        )
        probabilities = model.predict_proba(dense_eval)
        if probabilities.shape[1] == 2:
            probabilities = probabilities[:, 1]
        metadata = {"best_epoch": int(model.best_epoch), "best_cost": float(model.best_cost)}
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return PredictionResult(probabilities, metadata, model, preprocessor)

