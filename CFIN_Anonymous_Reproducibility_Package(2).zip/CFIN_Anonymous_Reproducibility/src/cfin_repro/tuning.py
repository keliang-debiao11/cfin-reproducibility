from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold

from .adapters import fit_predict
from .config import PROJECT_ROOT, resolved_experiment_config
from .data import fixed_split_indices, load_dataset
from .experiment import encode_target


def _suggest(trial, model: str) -> dict[str, Any]:
    if model == "logistic_regression":
        penalty = trial.suggest_categorical("penalty", ["l1", "l2"])
        solver = trial.suggest_categorical("solver", ["liblinear", "saga"])
        return {
            "C": trial.suggest_float("C", 1e-4, 1e3, log=True),
            "penalty": penalty,
            "solver": solver,
        }
    if model == "random_forest":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 200, 800),
            "max_depth": trial.suggest_categorical("max_depth", [4, 6, 8, 12, 16, None]),
            "min_samples_split": trial.suggest_int("min_samples_split", 2, 20),
            "max_features": trial.suggest_categorical("max_features", ["sqrt", "half", "all"]),
        }
    if model == "xgboost":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 200, 800),
            "max_depth": trial.suggest_int("max_depth", 3, 8),
            "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.20, log=True),
            "subsample": trial.suggest_float("subsample", 0.70, 1.00),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.70, 1.00),
            "min_child_weight": trial.suggest_float("min_child_weight", 1.0, 10.0),
        }
    common = {
        "dropout": trial.suggest_float("dropout", 0.05, 0.30),
        "learning_rate": trial.suggest_float("learning_rate", 3e-5, 5e-4, log=True),
        "weight_decay": trial.suggest_float("weight_decay", 1e-6, 1e-3, log=True),
        "batch_size": trial.suggest_categorical("batch_size", [128, 256, 512]),
        "focal_gamma": trial.suggest_categorical("focal_gamma", [1.0, 1.5, 2.0, 2.5]),
        "loss": "weighted_focal",
        "max_epochs": 200,
        "patience": 20,
        "min_delta": 1e-4,
        "gradient_clip_norm": 1.0,
    }
    if model == "mlp":
        width = trial.suggest_int("hidden_width", 128, 512, step=64)
        layers = trial.suggest_int("num_layers", 2, 4)
        common["hidden_dims"] = [max(64, width // (2**index)) for index in range(layers)]
        return common
    if model == "tabnet":
        common.update(
            {
                "n_d": trial.suggest_categorical("n_d", [16, 32, 64]),
                "n_a": trial.suggest_categorical("n_a", [16, 32, 64]),
                "n_steps": trial.suggest_int("n_steps", 3, 6),
                "gamma": trial.suggest_float("gamma", 1.2, 1.8),
                "lambda_sparse": trial.suggest_float("lambda_sparse", 1e-6, 1e-3, log=True),
            }
        )
        return common
    if model == "ft_transformer":
        common.update(
            {
                "token_dim": trial.suggest_categorical("token_dim", [64, 96, 128, 160, 192]),
                "layers": trial.suggest_int("layers", 2, 6),
                "heads": trial.suggest_categorical("heads", [4, 8, 16]),
                "ff_multiplier": trial.suggest_categorical("ff_multiplier", [2, 4]),
            }
        )
        return common
    if model == "cfin":
        token_dim = trial.suggest_categorical("token_dim", [64, 96, 128, 160])
        group_multiplier = trial.suggest_categorical("group_ff_multiplier", [2, 4])
        context_multiplier = trial.suggest_categorical("context_ff_multiplier", [2, 4])
        common.update(
            {
                "token_dim": token_dim,
                "group_encoder_layers": trial.suggest_int("group_encoder_layers", 1, 3),
                "group_encoder_heads": trial.suggest_categorical("group_encoder_heads", [2, 4, 8]),
                "group_ff_dim": token_dim * group_multiplier,
                "context_encoder_layers": trial.suggest_int("context_encoder_layers", 2, 6),
                "context_encoder_heads": trial.suggest_categorical("context_encoder_heads", [4, 8, 16]),
                "context_ff_dim": token_dim * context_multiplier,
                "prediction_hidden_dim": 64,
            }
        )
        return common
    raise ValueError(model)


def tune(
    config_path: str | Path,
    dataset_name: str,
    model_name: str,
    *,
    trials: int | None = None,
) -> dict[str, Any]:
    import optuna

    config = resolved_experiment_config(config_path)
    trial_count = int(trials or config["experiment"]["tuning_trials"])
    dataset = load_dataset(dataset_name)
    target, _ = encode_target(dataset_name, dataset.target)
    train_indices, _ = fixed_split_indices(dataset.target, seed=2025, test_size=0.20)
    train_target = target[train_indices]
    splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=2025)

    def objective(trial) -> float:
        parameters = _suggest(trial, model_name)
        trial.set_user_attr("resolved_parameters", parameters)
        scores = []
        for fold, (fold_train_local, fold_validation_local) in enumerate(
            splitter.split(train_indices, train_target)
        ):
            prediction = fit_predict(
                model_name,
                parameters,
                dataset,
                train_indices[fold_train_local],
                train_indices[fold_validation_local],
                target,
                seed=2025 + fold,
            )
            probabilities = np.asarray(prediction.probabilities)
            predicted = (
                (probabilities >= 0.5).astype(int)
                if probabilities.ndim == 1
                else probabilities.argmax(axis=1)
            )
            scores.append(
                f1_score(target[train_indices[fold_validation_local]], predicted, average="macro")
            )
        return float(np.mean(scores))

    sampler = optuna.samplers.TPESampler(seed=2025)
    study = optuna.create_study(direction="maximize", sampler=sampler)
    study.optimize(objective, n_trials=trial_count, gc_after_trial=True)
    output = {
        "dataset": dataset_name,
        "model": model_name,
        "tuning_seed": 2025,
        "folds": 5,
        "trials": trial_count,
        "best_validation_macro_f1": float(study.best_value),
        "best_parameters": study.best_trial.user_attrs["resolved_parameters"],
        "study_trials": [
            {
                "number": trial.number,
                "value": trial.value,
                "state": str(trial.state),
                "parameters": trial.params,
            }
            for trial in study.trials
        ],
        "provenance": "REAL_EXECUTION",
    }
    path = PROJECT_ROOT / "results/real/tuning" / dataset_name / f"{model_name}.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(output, indent=2, sort_keys=True), encoding="utf-8")
    return output

