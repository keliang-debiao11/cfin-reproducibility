# Simulated Reference Logs

Every file under `logs/simulated_reference/` and `results/simulated_reference/` is synthetic.

Purpose:

- demonstrate the expected output schema;
- guide implementation and automated result parsing;
- provide target ranges for debugging reproduction code;
- check that manuscript tables can be reconstructed from per-seed files.

These files are **not real training logs**, **not evidence of model performance**, and **not suitable for presentation as completed experiments**. Genuine runs must write to `logs/real/` and `results/real/`. The package validator rejects simulated provenance markers in real-output directories.

