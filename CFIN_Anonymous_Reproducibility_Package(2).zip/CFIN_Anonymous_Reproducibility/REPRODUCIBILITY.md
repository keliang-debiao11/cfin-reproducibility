# Reproducibility Protocol

## Fixed study design

- Train-test split: stratified 80/20 split with seed 2025.
- INELS: 19,100 records; 15,280 training records and 3,820 held-out test records.
- UCI: 4,424 records; 3,539 training records and 885 held-out test records.
- Hyperparameter selection: 100 Optuna trials per model-dataset pair, five-fold stratified cross-validation, mean validation macro-F1 objective.
- Final seeds: `11, 23, 37, 47, 59, 71, 83, 97, 109, 127`.
- Neural early stopping: a stratified 90/10 split carved from the fixed 80% training partition with seed 2025; 200 maximum epochs; patience 20; minimum improvement `1e-4`; restore the best validation checkpoint.
- INELS decision threshold: model-specific threshold selected from five-fold OOF predictions on the training partition; grid 0.05 to 0.95 in increments of 0.01; maximize macro-F1; ties resolved by the threshold closest to 0.50.
- UCI prediction: three-class argmax with no threshold tuning.
- Primary metrics: macro-F1 and one-versus-rest macro-AUC. Accuracy, macro-precision, and macro-recall are secondary.

## Leakage controls

1. The held-out test partition is created before preprocessing or tuning.
2. Imputation, scaling, encoding, feature grouping metadata, and class weights are fitted on training data only.
3. During tuning, preprocessing is refitted inside each training fold.
4. INELS thresholds are selected from OOF training predictions, never in-sample predictions or test labels.
5. The final early-stopping subset is carved from the training partition only.
6. School identifiers are excluded from predictors and used solely as group keys in the school-grouped analysis.

## CFIN selected configuration

- Feature-token dimension: 128.
- Group encoder: one layer per semantic group, four attention heads, feed-forward dimension 256.
- Context encoder: four layers, eight attention heads, feed-forward dimension 512.
- Activation: GELU; dropout: 0.10.
- Prediction head: LayerNorm -> Linear(128, 64) -> GELU -> Dropout -> Linear.
- Optimizer: AdamW; learning rate `1e-4`; weight decay `1e-4`.
- Batch size: 256; gradient clipping: 1.0; cosine learning-rate schedule.
- Class-weighted focal-loss gamma: 2.0.

## Dataset-specific preprocessing

### INELS

- Map `continue` to Retained and `drop` to Dropout.
- Exclude student and school identifiers from predictors.
- Remove science score from the principal feature set because it duplicates mathematics score in all 19,100 records.
- Treat 59 establishment years later than 2016 as missing.
- Clip mathematics, English, and science scores to `[0, 1]`.
- Median-impute numerical missingness using training data and add missingness indicators for affected variables.

### UCI

- Use Dropout, Enrolled, and Graduate as the three target classes.
- Standardize continuous predictors using training-fold statistics for models requiring scaled inputs.
- One-hot encode categorical inputs for conventional models and use feature-specific embeddings for neural models.
- Map unseen validation/test categories to an explicit unknown category.

## Analysis specifications

- Temporal/predictor horizon: INELS full versus score-excluded; UCI T0, T1, and T2.
- School sensitivity: five-fold `StratifiedGroupKFold` using school identifier; repeat across ten seeds; also exclude all school-context predictors.
- Component ablations: remove inter-group context encoder; flat encoding; weighted cross-entropy; unweighted cross-entropy.
- Grouping sensitivity: random assignments with seeds 101, 202, 303, 404, and 505; agglomerative clustering of normalized mutual-information similarities; alternative four-domain grouping.
- SHAP: `PermutationExplainer`; 256 stratified training background records; 1,000 stratified INELS test records; all 885 UCI test records; seed 2025.
- Efficiency: 100 warm-up passes and 1,000 synchronized timed passes at batch sizes 1 and 256; report medians across the ten fitted seeds.

## Simulated reference outputs

All example logs and result files in the simulated-reference directories are generated from the manuscript's aggregate values. They validate schemas, report generation, and internal arithmetic only. They must not be described as observed experiments.

