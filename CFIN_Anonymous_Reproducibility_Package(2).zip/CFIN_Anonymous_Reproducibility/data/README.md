# Data directory

Raw datasets are intentionally excluded from the repository.

Expected paths:

```text
data/raw/inels/StudentDropIndia.csv
data/raw/uci/data.csv
```

Run `python scripts/prepare_data.py --dataset all`. The preparation script validates record counts, target distributions, duplicate score columns, missing-value counts, and required grouping keys before producing deterministic processed files and split-index manifests under `data/processed/`.

