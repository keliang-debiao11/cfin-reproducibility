# CFIN Anonymous Reproducibility Repository

This repository provides an anonymous, end-to-end implementation of the Contextual Feature Interaction Network (CFIN) and the complete evaluation workflow described in the manuscript.

## Important log notice

The files under `logs/simulated_reference/` and `results/simulated_reference/` are **SIMULATED REFERENCE OUTPUTS FOR PIPELINE DEVELOPMENT ONLY**. They reproduce the structure and aggregate targets reported in the manuscript, but they are not evidence that the experiments were executed. A real run writes only to `logs/real/` and `results/real/`. Replace the simulated reference outputs with genuine run artifacts before using logs as empirical evidence.

## Included functionality

- CFIN with non-shared group encoders and an inter-group context encoder.
- Logistic regression, random forest, XGBoost, MLP, TabNet, and FT-Transformer baselines.
- Training-only preprocessing and a fixed stratified 80/20 train-test split.
- Five-fold out-of-fold threshold selection for every INELS classifier.
- A common 100-trial Optuna tuning budget.
- Ten-seed final evaluation and training-only early stopping.
- Temporal/predictor-horizon, school-grouped, school-context-excluded, component-ablation, and grouping-sensitivity analyses.
- Paired statistical comparisons, SHAP analysis, and computational profiling.
- Anonymous-repository, result-schema, and manuscript-consistency checks.

## Repository layout

```text
configs/                         Experiment and dataset specifications
data/                            Raw-data placement instructions only
logs/simulated_reference/       Clearly marked synthetic example logs
logs/real/                       Created by actual runs and ignored by git
results/simulated_reference/    Reference-format tables and JSONL outputs
results/real/                    Created by actual runs and ignored by git
scripts/                         User-facing experiment entry points
src/cfin_repro/                  Models, data pipeline, training, and analyses
tests/                           Fast unit and consistency tests
```

## Data placement

The datasets are not redistributed. Download them from their public sources and place the original files as follows:

```text
data/raw/inels/StudentDropIndia.csv
data/raw/uci/data.csv
```

- INELS: Kaggle `StudentDropIndia 2016` dataset.
- UCI: `Predict Students' Dropout and Academic Success`, dataset ID 697.

Column-name aliases are defined in `configs/datasets/`. The preparation command prints any unresolved columns and never silently guesses a target or school identifier.

## Environment

Recommended: Python 3.11 and CUDA 12.x when GPU execution is required.

```bash
conda env create -f environment.yml
conda activate cfin-repro
python -m pip install -e .
```

For a pip-only setup:

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Fast validation

The following commands do not train the models:

```bash
python scripts/validate_package.py
pytest -q
python scripts/run_experiment.py --config configs/experiments/main.yaml --dry-run
```

## Reproduce the main experiment

```bash
python scripts/prepare_data.py --dataset all
python scripts/run_experiment.py --config configs/experiments/main.yaml
python scripts/summarize_results.py --input results/real/main_seed_metrics.jsonl
```

Run one dataset or model during debugging:

```bash
python scripts/run_experiment.py --config configs/experiments/main.yaml --dataset inels --model cfin --seed 11
```

## Reproduce the additional analyses

```bash
python scripts/run_analysis.py --analysis temporal
python scripts/run_analysis.py --analysis school
python scripts/run_analysis.py --analysis ablation
python scripts/run_analysis.py --analysis grouping
python scripts/run_shap.py --dataset all
python scripts/run_efficiency.py
python scripts/run_statistics.py
```

## Output contract

Each real run records:

- resolved configuration and git commit;
- dataset fingerprint and split indices;
- fold assignments and preprocessing fingerprints;
- tuning history and selected hyperparameters;
- OOF thresholds for INELS;
- epoch-level training and early-stopping information;
- per-seed test metrics and predictions;
- aggregate mean, sample SD, and confidence intervals.

The validation command fails if simulated files appear under `logs/real/` or `results/real/`.

## Reproducibility boundary

The fixed train-test indices are generated from the public raw data with random seed 2025. Preprocessing, feature grouping, class weighting, cross-validation, threshold selection, and early stopping are refitted inside the relevant training partition or fold. Test labels are used only for final evaluation.

See `REPRODUCIBILITY.md` for the exact protocol and `SIMULATED_LOGS_NOTICE.md` before using any example logs.

